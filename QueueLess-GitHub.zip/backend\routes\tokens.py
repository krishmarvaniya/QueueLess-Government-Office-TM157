from flask import Blueprint, request, g, current_app, send_file
from backend.extensions import db
from backend.models.token import Token
from backend.models.office import Office
from backend.services.token_service import create_virtual_token
from backend.services.queue_service import cancel_user_token
from backend.utils.decorators import success_response, error_response, login_required
from backend.utils.validators import validate_required_fields
import io, os, textwrap, qrcode

tokens_bp = Blueprint('tokens', __name__, url_prefix='/api/tokens')

@tokens_bp.route('', methods=['POST'])
@login_required
def take_token():
    data = request.get_json() or {}
    missing = validate_required_fields(data, ['office_id', 'service_id'])
    if missing:
        return error_response(f"Missing required fields: {', '.join(missing)}", "VALIDATION_ERROR", 400)

    office_id = int(data['office_id'])
    service_id = int(data['service_id'])

    # Update Citizen Profile
    user = g.current_user
    if 'full_name' in data and data['full_name'].strip():
        user.full_name = data['full_name'].strip()
    if 'mobile' in data and data['mobile'].strip():
        user.mobile = data['mobile'].strip()
    if 'email' in data and data['email'].strip():
        user.email = data['email'].strip()
    if 'address' in data and data['address'].strip():
        user.address = data['address'].strip()
    if 'pin_code' in data and data['pin_code'].strip():
        user.pin_code = data['pin_code'].strip()
    if 'city' in data and data['city'].strip():
        user.city = data['city'].strip()
    if 'state' in data and data['state'].strip():
        user.state = data['state'].strip()
    db.session.commit()

    office = Office.query.get(office_id)
    if not office or not office.is_active:
        return error_response("Office is currently inactive or not found.", "OFFICE_UNAVAILABLE", 400)

    # Check Operating Hours
    enforce_hours = current_app.config.get('ENFORCE_OFFICE_HOURS', True)
    if enforce_hours and not office.is_open_now():
        open_str = office.opening_time.strftime('%I:%M %p') if office.opening_time else '09:00 AM'
        close_str = office.closing_time.strftime('%I:%M %p') if office.closing_time else '05:00 PM'
        return error_response(
            f"Office is currently closed. Operating hours: {open_str} - {close_str}.",
            "OFFICE_CLOSED",
            400,
            details={'opening_time': open_str, 'closing_time': close_str}
        )

    token, err = create_virtual_token(g.current_user.id, office_id, service_id)
    if err:
        return error_response(err, "TOKEN_CREATION_FAILED", 400)

    return success_response(token.to_dict(), "Virtual token generated successfully!", 201)

@tokens_bp.route('/my', methods=['GET'])
@login_required
def get_my_tokens():
    # Return active tokens and past tokens
    active_tokens = Token.query.filter(
        Token.user_id == g.current_user.id,
        Token.status.in_(['WAITING', 'SERVING'])
    ).order_by(Token.issued_at.desc()).all()

    past_tokens = Token.query.filter(
        Token.user_id == g.current_user.id,
        Token.status.in_(['COMPLETED', 'SKIPPED', 'CANCELLED'])
    ).order_by(Token.created_at.desc()).limit(30).all()

    return success_response({
        'active': [t.to_dict() for t in active_tokens],
        'history': [t.to_dict() for t in past_tokens]
    }, "Tokens retrieved", 200)

@tokens_bp.route('/<int:token_id>', methods=['GET'])
@login_required
def get_token(token_id):
    token = Token.query.get(token_id)
    if not token:
        return error_response("Token not found", "NOT_FOUND", 404)

    # Users can view their own tokens, officers and admins can view any
    if g.current_user.role == 'citizen' and token.user_id != g.current_user.id:
        return error_response("Unauthorized to view this token", "FORBIDDEN", 403)

    return success_response(token.to_dict(), "Token details retrieved", 200)

@tokens_bp.route('/<int:token_id>/cancel', methods=['POST'])
@login_required
def cancel_token(token_id):
    token, err = cancel_user_token(token_id, g.current_user.id)
    if err:
        return error_response(err, "CANCEL_FAILED", 400)

    return success_response(token.to_dict(), "Token has been successfully cancelled", 200)

@tokens_bp.route('/verify/<string:token_number>', methods=['GET'])
def verify_token(token_number):
    """
    Public verification endpoint for QR code scans.
    Returns non-sensitive verification details.
    """
    token = Token.query.filter_by(token_number=token_number).first()
    if not token:
        return error_response("Invalid token or token record not found.", "INVALID_TOKEN", 404)

    return success_response({
        'token_number': token.token_number,
        'office': token.office.name if token.office else None,
        'service': token.service.name if token.service else None,
        'status': token.status,
        'counter': token.counter.counter_number if token.counter else 'Pending',
        'issued_at': token.issued_at.strftime('%Y-%m-%d %I:%M %p') if token.issued_at else None,
        'is_valid': token.status in ['WAITING', 'SERVING']
    }, "Token verification details", 200)
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas
from reportlab.lib.utils import ImageReader

@tokens_bp.route('/<int:token_id>/download/txt', methods=['GET'])
@login_required
def download_txt(token_id):
    token = Token.query.get(token_id)
    if not token or (g.current_user.role == 'citizen' and token.user_id != g.current_user.id):
        return error_response("Unauthorized or Not Found", "UNAUTHORIZED", 403)
    
    t = token.to_dict()
    
    verify_url = f"{request.host_url}verify?t={t['token_number']}"
    
    content = f"""QUEUELESS GOVERNMENT OFFICE
DIGITAL TOKEN INVOICE
----------------------------------------

CITIZEN INFORMATION
Full Name       : {t.get('citizen_name') or 'N/A'}
Mobile Number   : {t.get('citizen_mobile') or 'N/A'}
Email Address   : {t.get('citizen_email') or 'N/A'}
Address         : {t.get('citizen_address') or 'N/A'}
PIN Code        : {t.get('citizen_pin_code') or 'N/A'}
City            : {t.get('citizen_city') or 'N/A'}
State           : {t.get('citizen_state') or 'N/A'}

TOKEN INFORMATION
Token Number    : {t.get('token_number') or 'N/A'}
Service         : {t.get('service_name') or 'N/A'}
Office          : {t.get('office_name') or 'N/A'}
Office Address  : {t.get('office_address') or 'N/A'}
Counter         : {t.get('counter_number') or 'Pending'}
Created At      : {t.get('issued_at') or 'N/A'}
Queue Position  : {t.get('queue_position') or 'N/A'}
Estimated Wait  : {t.get('estimated_wait_minutes') or 'N/A'} min
Status          : {t.get('status') or 'N/A'}

QR Verification : {verify_url}

----------------------------------------
Generated by QueueLess Government Office"""
    
    buf = io.BytesIO(content.encode('utf-8'))
    return send_file(buf, mimetype='text/plain', as_attachment=True, download_name=f"QueueLess-Token-{t['token_number']}.txt")

@tokens_bp.route('/<int:token_id>/download/pdf', methods=['GET'])
@login_required
def download_pdf(token_id):
    token = Token.query.get(token_id)
    if not token or (g.current_user.role == 'citizen' and token.user_id != g.current_user.id):
        return error_response("Unauthorized or Not Found", "UNAUTHORIZED", 403)
    
    t = token.to_dict()
    verify_url = f"{request.host_url}verify?t={t['token_number']}"
    
    buf = io.BytesIO()
    c = canvas.Canvas(buf, pagesize=A4)
    width, height = A4
    
    c.setFont("Helvetica-Bold", 16)
    c.drawCentredString(width / 2.0, height - 50, "QUEUELESS GOVERNMENT OFFICE")
    c.setFont("Helvetica", 14)
    c.drawCentredString(width / 2.0, height - 70, "DIGITAL TOKEN INVOICE")
    
    c.line(50, height - 85, width - 50, height - 85)
    
    y = height - 120
    c.setFont("Helvetica-Bold", 12)
    c.drawString(50, y, "CITIZEN INFORMATION")
    y -= 20
    
    c.setFont("Helvetica", 10)
    info = [
        ("Full Name", t.get('citizen_name')),
        ("Mobile Number", t.get('citizen_mobile')),
        ("Email Address", t.get('citizen_email')),
        ("Address", t.get('citizen_address')),
        ("PIN Code", t.get('citizen_pin_code')),
        ("City", t.get('citizen_city')),
        ("State", t.get('citizen_state'))
    ]
    for label, val in info:
        val_str = str(val) if val else 'N/A'
        wrapped = textwrap.wrap(val_str, width=60)
        c.drawString(50, y, f"{label:<15} : {wrapped[0]}")
        y -= 15
        for line in wrapped[1:]:
            c.drawString(50, y, f"{' ':<15}   {line}")
            y -= 15
            
    y -= 10
    c.setFont("Helvetica-Bold", 12)
    c.drawString(50, y, "TOKEN INFORMATION")
    y -= 20
    
    c.setFont("Helvetica", 10)
    token_info = [
        ("Token Number", t.get('token_number')),
        ("Service", t.get('service_name')),
        ("Office", t.get('office_name')),
        ("Office Address", t.get('office_address')),
        ("Counter", t.get('counter_number') or 'Pending'),
        ("Created At", t.get('issued_at')),
        ("Queue Position", t.get('queue_position')),
        ("Estimated Wait", f"{t.get('estimated_wait_minutes')} min" if t.get('estimated_wait_minutes') else 'N/A'),
        ("Status", t.get('status'))
    ]
    for label, val in token_info:
        val_str = str(val) if val else 'N/A'
        wrapped = textwrap.wrap(val_str, width=60)
        c.drawString(50, y, f"{label:<15} : {wrapped[0]}")
        y -= 15
        for line in wrapped[1:]:
            c.drawString(50, y, f"{' ':<15}   {line}")
            y -= 15

    y -= 10
    c.setFont("Helvetica-Bold", 12)
    c.drawString(50, y, "QR VERIFICATION")
    y -= 20
    c.setFont("Helvetica", 10)
    c.drawString(50, y, "Scan the QR code below to verify this token:")
    
    # Generate QR Code image
    qr = qrcode.QRCode(version=1, box_size=5, border=2)
    qr.add_data(verify_url)
    qr.make(fit=True)
    img = qr.make_image(fill_color="black", back_color="white")
    
    img_byte_arr = io.BytesIO()
    img.save(img_byte_arr, format='PNG')
    img_byte_arr.seek(0)
    
    qr_img = ImageReader(img_byte_arr)
    c.drawImage(qr_img, 50, y - 120, width=100, height=100)
    
    y -= 150
    c.line(50, y, width - 50, y)
    y -= 15
    c.setFont("Helvetica-Oblique", 9)
    c.drawCentredString(width / 2.0, y, "Generated by QueueLess Government Office")
    
    c.save()
    buf.seek(0)
    
    return send_file(buf, mimetype='application/pdf', as_attachment=True, download_name=f"QueueLess-Token-{t['token_number']}.pdf")
