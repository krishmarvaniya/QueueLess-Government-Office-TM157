from datetime import datetime
from backend.extensions import db

class Service(db.Model):
    __tablename__ = 'services'

    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    office_id = db.Column(db.Integer, db.ForeignKey('offices.id', ondelete='CASCADE'), nullable=False, index=True)
    name = db.Column(db.String(150), nullable=False)
    code = db.Column(db.String(20), nullable=False)
    description = db.Column(db.Text, nullable=True)
    average_service_time = db.Column(db.Integer, nullable=False, default=15) # minutes
    is_active = db.Column(db.Boolean, default=True, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    __table_args__ = (
        db.UniqueConstraint('office_id', 'code', name='uk_office_service_code'),
    )

    # Relationships
    tokens = db.relationship('Token', backref='service', lazy='dynamic', cascade='all, delete-orphan')

    def to_dict(self):
        return {
            'id': self.id,
            'office_id': self.office_id,
            'office_name': self.office.name if self.office else None,
            'name': self.name,
            'code': self.code,
            'description': self.description,
            'average_service_time': self.average_service_time,
            'is_active': self.is_active,
            'created_at': self.created_at.strftime('%Y-%m-%d %H:%M:%S') if self.created_at else None
        }
