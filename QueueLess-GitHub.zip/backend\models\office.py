from datetime import datetime, time
from backend.extensions import db

class Office(db.Model):
    __tablename__ = 'offices'

    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    name = db.Column(db.String(150), nullable=False)
    code = db.Column(db.String(20), unique=True, nullable=False, index=True)
    address = db.Column(db.String(255), nullable=False)
    city = db.Column(db.String(100), nullable=False)
    state = db.Column(db.String(100), nullable=False)
    opening_time = db.Column(db.Time, nullable=False, default=time(9, 0))
    closing_time = db.Column(db.Time, nullable=False, default=time(17, 0))
    is_active = db.Column(db.Boolean, default=True, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    # Relationships
    services = db.relationship('Service', backref='office', lazy='dynamic', cascade='all, delete-orphan')
    counters = db.relationship('Counter', backref='office', lazy='dynamic', cascade='all, delete-orphan')
    tokens = db.relationship('Token', backref='office', lazy='dynamic', cascade='all, delete-orphan')

    def is_open_now(self, check_time=None) -> bool:
        if not self.is_active:
            return False
        if check_time is None:
            check_time = datetime.now().time()
        # Direct comparison handles same day hours
        if self.opening_time <= self.closing_time:
            return self.opening_time <= check_time <= self.closing_time
        # Overnight operating hours
        return check_time >= self.opening_time or check_time <= self.closing_time

    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'code': self.code,
            'address': self.address,
            'city': self.city,
            'state': self.state,
            'opening_time': self.opening_time.strftime('%H:%M:%S') if self.opening_time else '09:00:00',
            'closing_time': self.closing_time.strftime('%H:%M:%S') if self.closing_time else '17:00:00',
            'is_active': self.is_active,
            'created_at': self.created_at.strftime('%Y-%m-%d %H:%M:%S') if self.created_at else None,
            'services_count': self.services.count() if hasattr(self, 'services') else 0,
            'counters_count': self.counters.count() if hasattr(self, 'counters') else 0
        }
