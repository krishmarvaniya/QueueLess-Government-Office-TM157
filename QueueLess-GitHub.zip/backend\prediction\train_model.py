import os
import sys

# Ensure root dir is in sys.path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../..')))

from ml.train_model import train_and_save

if __name__ == "__main__":
    csv_path = os.path.abspath(os.path.join(os.path.dirname(__file__), '../../ml/dataset.csv'))
    model_path = os.path.abspath(os.path.join(os.path.dirname(__file__), 'model.pkl'))
    train_and_save(csv_path, model_path)
