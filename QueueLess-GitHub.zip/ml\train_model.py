import os
import joblib
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, r2_score

FEATURE_COLS = [
    'queue_length',
    'people_ahead',
    'active_counters',
    'average_service_time',
    'hour',
    'day_of_week'
]
TARGET_COL = 'actual_wait'

def train_and_save(csv_path="ml/dataset.csv", output_model_path="backend/prediction/model.pkl"):
    if not os.path.exists(csv_path):
        raise FileNotFoundError(f"Training dataset not found at {csv_path}")

    print(f"Loading dataset from {csv_path}...")
    df = pd.read_csv(csv_path)

    # Validate columns
    for col in FEATURE_COLS + [TARGET_COL]:
        if col not in df.columns:
            raise ValueError(f"Missing column '{col}' in dataset")

    X = df[FEATURE_COLS]
    y = df[TARGET_COL]

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    model = None
    try:
        print("Training RandomForestRegressor model...")
        rf = RandomForestRegressor(n_estimators=100, max_depth=12, random_state=42)
        rf.fit(X_train, y_train)
        model = rf
        model_name = "RandomForestRegressor"
    except Exception as e:
        print(f"RandomForest failed: {e}. Falling back to LinearRegression...")
        lr = LinearRegression()
        lr.fit(X_train, y_train)
        model = lr
        model_name = "LinearRegression"

    y_pred = model.predict(X_test)
    mae = mean_absolute_error(y_test, y_pred)
    r2 = r2_score(y_test, y_pred)

    print(f"Model: {model_name}")
    print(f"Mean Absolute Error (MAE): {mae:.2f} minutes")
    print(f"R² Score: {r2:.4f}")

    os.makedirs(os.path.dirname(output_model_path), exist_ok=True)
    payload = {
        'model': model,
        'model_name': model_name,
        'features': FEATURE_COLS,
        'mae': round(mae, 2),
        'r2': round(r2, 4)
    }
    joblib.dump(payload, output_model_path)
    print(f"Successfully saved trained model to {output_model_path}")
    return payload

if __name__ == "__main__":
    train_and_save()
