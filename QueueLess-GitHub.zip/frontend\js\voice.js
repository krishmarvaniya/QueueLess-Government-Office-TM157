/* ===================================================
   QueueLess Government Office — Voice Announcement Engine
   Uses Web Speech API (speechSynthesis). No external API needed.
   =================================================== */

const VoiceAnnouncer = (() => {
    /* ── Internal state ── */
    let _supported = typeof window !== 'undefined' && 'speechSynthesis' in window;
    let _lastAnnouncedTokenId = null;   // prevents duplicate auto-announcements
    let _preferredVoice = null;

    /* ── Pick a clear English voice once voices are loaded ── */
    function _pickVoice() {
        if (!_supported) return;
        const voices = window.speechSynthesis.getVoices();
        if (!voices.length) return;

        // Priority order: en-IN (local), en-GB, en-US, any English, then first available
        const priorities = [
            v => v.lang === 'en-IN' && !v.localService === false,
            v => v.lang === 'en-IN',
            v => v.lang === 'en-US' && v.localService,
            v => v.lang === 'en-GB' && v.localService,
            v => v.lang.startsWith('en') && v.localService,
            v => v.lang.startsWith('en'),
            v => true,
        ];
        for (const test of priorities) {
            const match = voices.find(test);
            if (match) { _preferredVoice = match; break; }
        }
    }

    if (_supported) {
        window.speechSynthesis.onvoiceschanged = _pickVoice;
        // Some browsers already have voices synchronously
        _pickVoice();
    }

    /* ── Convert a token number like "CERT-101" into speakable text ──
       "CERT-101" → "C E R T, one zero one"
       "A-012"    → "A, zero one two"
       "TST-003"  → "T S T, zero zero three"
    ── */
    function _spellToken(tokenNumber) {
        if (!tokenNumber) return 'unknown token';
        const parts = String(tokenNumber).split('-');
        const spelled = parts.map((part, idx) => {
            // If purely alphabetic, spell it out letter by letter
            if (/^[A-Za-z]+$/.test(part)) {
                return part.toUpperCase().split('').join(' ');
            }
            // If purely numeric, read each digit individually
            if (/^\d+$/.test(part)) {
                const digitWords = { '0': 'zero', '1': 'one', '2': 'two', '3': 'three',
                    '4': 'four', '5': 'five', '6': 'six', '7': 'seven',
                    '8': 'eight', '9': 'nine' };
                return part.split('').map(d => digitWords[d] || d).join(' ');
            }
            // Mixed: spell char by char
            return part.split('').join(' ');
        });
        return spelled.join(', ');
    }

    /* ── Build the full announcement text ── */
    function _buildText(tokenNumber, counterNumber) {
        const spelledToken = _spellToken(tokenNumber);
        const counter = counterNumber ? counterNumber : 'the service counter';
        return `Token ${spelledToken}. Please proceed to ${counter}.`;
    }

    /* ── Core speak function ── */
    function _speak(text) {
        if (!_supported) {
            console.warn('[VoiceAnnouncer] Web Speech API not supported in this browser.');
            return;
        }
        // Cancel any ongoing speech
        window.speechSynthesis.cancel();

        const utter = new SpeechSynthesisUtterance(text);
        utter.rate   = 0.88;   // slightly slower for clarity
        utter.pitch  = 1.0;
        utter.volume = 1.0;
        if (_preferredVoice) utter.voice = _preferredVoice;

        utter.onerror = (e) => {
            // 'interrupted' is normal when we cancel; suppress it
            if (e.error !== 'interrupted') {
                console.warn('[VoiceAnnouncer] Speech error:', e.error);
            }
        };

        // Work around Chrome bug that stops synthesis after ~15 s
        const keepAlive = setInterval(() => {
            if (!window.speechSynthesis.speaking) { clearInterval(keepAlive); return; }
            window.speechSynthesis.pause();
            window.speechSynthesis.resume();
        }, 10000);

        utter.onend = () => clearInterval(keepAlive);

        window.speechSynthesis.speak(utter);
    }

    /* ── Public API ── */
    return {
        /** Returns true if the browser supports speech synthesis. */
        isSupported() { return _supported; },

        /**
         * Automatically announce a newly called token.
         * Deduplication: if tokenId == lastAnnouncedTokenId, stays silent
         * (prevents polling/socket echoes from repeating the announcement).
         *
         * @param {string} tokenNumber  e.g. "CERT-101"
         * @param {string} counterNumber e.g. "Counter 1"
         * @param {number|string} tokenId  unique DB id for dedup
         */
        announceNew(tokenNumber, counterNumber, tokenId) {
            if (!tokenNumber) return;
            const id = String(tokenId);
            if (_lastAnnouncedTokenId === id) return;  // duplicate guard
            _lastAnnouncedTokenId = id;
            _speak(_buildText(tokenNumber, counterNumber));
        },

        /**
         * Always announce — used by the Recall / Re-announce button.
         * Ignores deduplication so every deliberate click repeats.
         *
         * @param {string} tokenNumber
         * @param {string} counterNumber
         */
        recall(tokenNumber, counterNumber) {
            if (!tokenNumber) return;
            _speak(_buildText(tokenNumber, counterNumber));
        },

        /**
         * Reset the last-announced token so the next announceNew() will always fire.
         * Call this on page load to prevent stale state.
         */
        reset() {
            _lastAnnouncedTokenId = null;
        },

        /** Cancel any in-progress speech immediately. */
        cancel() {
            if (_supported) window.speechSynthesis.cancel();
        },
    };
})();
