from flask import Blueprint, request
from backend.models.token import Token
from backend.services.queue_service import get_office_queue_summary
from backend.utils.decorators import success_response, error_response

queue_bp = Blueprint('queue', __name__, url_prefix='/api/queue')

@queue_bp.route('/<int:office_id>', methods=['GET'])
def get_office_queue(office_id):
    summary = get_office_queue_summary(office_id)
    return success_response(summary, "Office queue status retrieved", 200)

@queue_bp.route('/tv-display', methods=['GET'])
def get_tv_display_data():
    """
    Public read-only endpoint for the TV Token Display.
    Returns serving + waiting tokens for an office, optionally filtered by service.
    No PII is included — only token number, service name, status, and counter.
    Officers can only see their own assigned service's data (enforced via optional auth).
    """
    office_id = request.args.get('office_id', type=int)
    service_id = request.args.get('service_id', type=int)

    if not office_id:
        return error_response("Office ID is required", "MISSING_OFFICE", 400)

    # Optional: apply officer service restriction if a valid Bearer token is provided
    try:
        from flask import g
        from backend.utils.auth import decode_auth_token
        auth_header = request.headers.get('Authorization', '')
        if auth_header.startswith('Bearer '):
            token_str = auth_header.split(' ', 1)[1].strip()
            payload = decode_auth_token(token_str)
            if payload and 'user_id' in payload:
                from backend.models.user import User
                user = User.query.get(payload['user_id'])
                if user and user.role == 'officer' and user.assigned_service_id:
                    if service_id and service_id != user.assigned_service_id:
                        return error_response("Unauthorized service filter", "FORBIDDEN", 403)
                    service_id = user.assigned_service_id
    except Exception:
        pass  # Allow unauthenticated access; officer restriction is best-effort

    serving_query = Token.query.filter_by(office_id=office_id, status='SERVING')
    waiting_query = Token.query.filter_by(office_id=office_id, status='WAITING')

    if service_id:
        serving_query = serving_query.filter_by(service_id=service_id)
        waiting_query = waiting_query.filter_by(service_id=service_id)

    serving = serving_query.order_by(Token.called_at.desc()).all()
    waiting = waiting_query.order_by(Token.issued_at.asc()).limit(15).all()

    def safe_token_dict(t):
        return {
            'id': t.id,
            'token_number': t.token_number,
            'service_name': t.service.name if t.service else 'Unknown',
            'status': t.status,
            'counter_number': t.counter.counter_number if t.counter else None
        }

    return success_response({
        'office_id': office_id,
        'service_id': service_id,
        'serving': [safe_token_dict(t) for t in serving],
        'waiting': [safe_token_dict(t) for t in waiting]
    }, "TV display data retrieved", 200)

@queue_bp.route('/token/<int:token_id>', methods=['GET'])
def get_token_queue_status(token_id):
    token = Token.query.get(token_id)
    if not token:
        return error_response("Token not found", "NOT_FOUND", 404)

    if token.status == 'WAITING':
        people_ahead = Token.query.filter(
            Token.office_id == token.office_id,
            Token.service_id == token.service_id,
            Token.status == 'WAITING',
            Token.issued_at < token.issued_at
        ).count()
        position = people_ahead + 1
    elif token.status == 'SERVING':
        people_ahead = 0
        position = 0
    else:
        people_ahead = 0
        position = 0

    current_serving = Token.query.filter_by(
        office_id=token.office_id,
        service_id=token.service_id,
        status='SERVING'
    ).order_by(Token.called_at.desc()).first()

    data = {
        'token': token.to_dict(),
        'queue_position': position,
        'people_ahead': people_ahead,
        'current_serving_token': current_serving.token_number if current_serving else "None",
        'current_serving_counter': current_serving.counter.counter_number if current_serving and current_serving.counter else None,
        'estimated_wait_minutes': token.estimated_wait_minutes,
        'recommended_arrival': token.recommended_arrival.strftime('%I:%M %p') if token.recommended_arrival else None
    }

    return success_response(data, "Token queue position retrieved", 200)
