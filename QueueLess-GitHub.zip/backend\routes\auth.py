from flask import Blueprint, request, session, g
from werkzeug.security import generate_password_hash
from backend.extensions import db
from backend.models.user import User
from backend.models.audit_log import AuditLog
from backend.utils.auth import generate_auth_token
from backend.utils.validators import validate_email, validate_mobile, validate_password, validate_required_fields
from backend.utils.decorators import success_response, error_response, login_required
import logging

logger = logging.getLogger(__name__)

auth_bp = Blueprint('auth', __name__, url_prefix='/api/auth')

# ------------------------------------------------------------------ #
#  Registration
# ------------------------------------------------------------------ #

@auth_bp.route('/register', methods=['POST'])
def register():
    data = request.get_json() or {}
    missing = validate_required_fields(data, ['full_name', 'email', 'mobile', 'password', 'confirm_password'])
    if missing:
        return error_response(f"Missing required fields: {', '.join(missing)}", "VALIDATION_ERROR", 400)

    full_name        = data['full_name'].strip()
    email            = data['email'].strip().lower()
    mobile           = data['mobile'].strip()
    password         = data['password']
    confirm_password = data['confirm_password']

    if password != confirm_password:
        return error_response("Passwords do not match.", "PASSWORD_MISMATCH", 400)

    if not validate_email(email):
        return error_response(
            "Please enter a valid Gmail address ending with @gmail.com.",
            "INVALID_EMAIL", 400
        )

    if not validate_mobile(mobile):
        return error_response(
            "Please enter a valid 10-digit Indian mobile number starting with 6, 7, 8, or 9.",
            "INVALID_MOBILE", 400
        )

    is_valid_pw, pw_err = validate_password(password)
    if not is_valid_pw:
        return error_response(pw_err, "WEAK_PASSWORD", 400)

    if User.query.filter_by(email=email).first():
        return error_response("This email is already registered.", "EMAIL_EXISTS", 409)

    if User.query.filter_by(mobile=mobile).first():
        return error_response("This phone number is already registered.", "MOBILE_EXISTS", 409)

    user = User(
        full_name = full_name,
        email     = email,
        mobile    = mobile,
        role      = 'citizen',
        is_active = True,
    )
    user.password_hash = generate_password_hash(password)

    db.session.add(user)
    db.session.flush()

    # Assign the next sequential display number
    from sqlalchemy import func as sqlfunc
    max_display = db.session.query(sqlfunc.max(User.display_number)).scalar() or 0
    user.display_number = max_display + 1

    audit = AuditLog(
        user_id     = user.id,
        action      = 'USER_REGISTER',
        entity_type = 'USER',
        entity_id   = user.id,
        details     = f"User {user.email} registered."
    )
    db.session.add(audit)
    db.session.commit()

    return success_response(None, "Registration successful.", 201)

# ------------------------------------------------------------------ #
#  Login
# ------------------------------------------------------------------ #

@auth_bp.route('/login', methods=['POST'])
def login():
    data = request.get_json() or {}
    missing = validate_required_fields(data, ['email', 'password'])
    if missing:
        return error_response(f"Missing required fields: {', '.join(missing)}", "VALIDATION_ERROR", 400)

    email    = data['email'].strip().lower()
    password = data['password']

    user = User.query.filter_by(email=email).first()
    if not user or not user.check_password(password):
        return error_response("Invalid email or password.", "INVALID_CREDENTIALS", 401)

    if not user.is_active:
        return error_response(
            "Your account has been deactivated. Please contact the administrator.",
            "ACCOUNT_INACTIVE", 403
        )

    token = generate_auth_token(user.id, user.role)
    session['user_id'] = user.id

    audit = AuditLog(
        user_id=user.id, action='LOGIN', entity_type='USER',
        entity_id=user.id, details=f"User {user.email} logged in."
    )
    db.session.add(audit)
    db.session.commit()

    return success_response({'token': token, 'user': user.to_dict()}, "Login successful.", 200)

# ------------------------------------------------------------------ #
#  Logout
# ------------------------------------------------------------------ #

@auth_bp.route('/logout', methods=['POST'])
def logout():
    user_id = session.get('user_id')
    if user_id:
        audit = AuditLog(
            user_id=user_id, action='LOGOUT', entity_type='USER',
            entity_id=user_id, details="User logged out."
        )
        db.session.add(audit)
        db.session.commit()
    session.clear()
    return success_response(None, "Successfully logged out.", 200)

# ------------------------------------------------------------------ #
#  Current user
# ------------------------------------------------------------------ #

@auth_bp.route('/me', methods=['GET'])
@login_required
def get_current_user():
    user_dict = g.current_user.to_dict()
    if g.current_user.role == 'officer':
        counter = g.current_user.assigned_counters.first()
        user_dict['assigned_counter'] = counter.to_dict() if counter else None
    return success_response(user_dict, "Current user profile fetched.", 200)

@auth_bp.route('/me', methods=['PUT'])
@login_required
def update_current_user():
    data = request.get_json() or {}
    user = g.current_user
    
    if 'full_name' in data and data['full_name'].strip():
        user.full_name = data['full_name'].strip()
    if 'mobile' in data and data['mobile'].strip():
        user.mobile = data['mobile'].strip()
    if 'email' in data and data['email'].strip():
        user.email = data['email'].strip()
    if 'address' in data:
        user.address = data['address'].strip() if data['address'] else None
    if 'pin_code' in data:
        user.pin_code = data['pin_code'].strip() if data['pin_code'] else None
    if 'city' in data:
        user.city = data['city'].strip() if data['city'] else None
    if 'state' in data:
        user.state = data['state'].strip() if data['state'] else None

    db.session.commit()
    return success_response(user.to_dict(), "Profile updated successfully.", 200)
