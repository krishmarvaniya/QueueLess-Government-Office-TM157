# QueueLess Government Office — REST API Documentation

Base URL: `/api`

All protected requests require an HTTP Authorization header:
```http
Authorization: Bearer <TOKEN>
```

Consistent JSON Response Format:
```json
{
  "success": true,
  "message": "Operation description",
  "data": {}
}
```

---

## 1. Authentication (`/api/auth`)

### `POST /api/auth/register`
- **Access**: Public
- **Body**: `{ "full_name": "...", "email": "...", "mobile": "...", "password": "..." }`
- **Response**: `201 Created` with signed session token and user profile.

### `POST /api/auth/login`
- **Access**: Public
- **Body**: `{ "email": "...", "password": "..." }`
- **Response**: `200 OK` with user token and role.

### `POST /api/auth/logout`
- **Access**: Authenticated
- **Response**: `200 OK`

### `GET /api/auth/me`
- **Access**: Authenticated
- **Response**: `200 OK` with profile and assigned counter (if officer).

---

## 2. Offices (`/api/offices`)

### `GET /api/offices`
- Returns all active offices with operational status (`is_open: true/false`).

### `POST /api/offices` (Admin)
- Creates new administrative office and sets operating hours.

---

## 3. Services (`/api/services`)

### `GET /api/services?office_id=<id>`
- Returns services matching office, including benchmark durations.

### `POST /api/services` (Admin)
- Adds a service to an office with average processing time.

---

## 4. Virtual Tokens (`/api/tokens`)

### `POST /api/tokens`
- **Access**: Authenticated (Citizen)
- **Body**: `{ "office_id": 1, "service_id": 2 }`
- **Validation**: Enforces operating hours and blocks duplicate active tokens.
- **Actions**: Issues next serial number (e.g. `CERT-104`), computes ML wait time, creates verified QR code image, and broadcasts real-time socket event.

### `GET /api/tokens/my`
- Returns citizen's active tokens and previous token history.

### `POST /api/tokens/<id>/cancel`
- Cancels waiting token and recalculates remaining queue positions.

### `GET /api/tokens/verify/<token_number>`
- **Access**: Public QR scanner
- Validates token without exposing sensitive user credentials.

---

## 5. Officer Terminal (`/api/officer`)

### `GET /api/officer/status`
- Returns current officer counter, currently serving token, and next in line.

### `POST /api/officer/next`
- Calls next FIFO waiting token, assigns it to officer's counter, logs call timestamp, triggers sound alert, and notifies citizen.

### `POST /api/officer/token/<id>/complete`
- Marks token as `COMPLETED` and calculates actual wait time for ML feedback.

### `POST /api/officer/token/<id>/skip`
- Marks token as `SKIPPED`.

### `POST /api/officer/token/<id>/recall`
- Re-announces token number across facility displays.

---

## 6. Reports & Analytics (`/api/reports`, `/api/admin`)

- `GET /api/reports/daily`
- `GET /api/reports/weekly`
- `GET /api/reports/monthly`
- `GET /api/admin/analytics`
