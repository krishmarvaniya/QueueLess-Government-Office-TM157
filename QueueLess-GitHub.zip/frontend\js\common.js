/* ===================================================
   QueueLess Government Office - Common Utilities
   =================================================== */

// Ensure Toast Container exists
function ensureToastContainer() {
    let container = document.getElementById('toast-container');
    if (!container) {
        container = document.createElement('div');
        container.id = 'toast-container';
        document.body.appendChild(container);
    }
    return container;
}

/**
 * Display toast notification.
 * @param {'success'|'info'|'warning'|'error'} type 
 * @param {string} title 
 * @param {string} message 
 * @param {number} durationMs 
 */
function showToast(type = 'info', title = '', message = '', durationMs = 4500) {
    const container = ensureToastContainer();
    const toast = document.createElement('div');
    toast.className = `gov-toast toast-${type}`;

    const iconMap = {
        success: 'bi-check-circle-fill',
        info: 'bi-info-circle-fill',
        warning: 'bi-exclamation-triangle-fill',
        error: 'bi-x-circle-fill'
    };

    const iconClass = iconMap[type] || 'bi-info-circle-fill';

    toast.innerHTML = `
        <i class="bi ${iconClass} toast-icon"></i>
        <div class="toast-content">
            <div class="toast-title">${escapeHtml(title || type.toUpperCase())}</div>
            <div class="toast-message">${escapeHtml(message)}</div>
        </div>
        <button type="button" class="toast-close" aria-label="Close">&times;</button>
    `;

    const closeBtn = toast.querySelector('.toast-close');
    closeBtn.addEventListener('click', () => removeToast(toast));

    container.appendChild(toast);

    const timer = setTimeout(() => {
        removeToast(toast);
    }, durationMs);

    function removeToast(el) {
        clearTimeout(timer);
        el.style.animation = 'toastSlideOut 0.25s cubic-bezier(0.16, 1, 0.3, 1) forwards';
        setTimeout(() => el.remove(), 250);
    }
}

function escapeHtml(str) {
    if (!str) return '';
    return String(str)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#039;');
}

/**
 * Manage loading spinner on buttons to prevent double-submissions.
 */
function setButtonLoading(button, isLoading, loadingText = 'Processing...') {
    if (!button) return;
    if (isLoading) {
        button.dataset.originalHtml = button.innerHTML;
        button.disabled = true;
        button.innerHTML = `<span class="spinner me-2"></span>${loadingText}`;
    } else {
        button.disabled = false;
        if (button.dataset.originalHtml) {
            button.innerHTML = button.dataset.originalHtml;
        }
    }
}

/**
 * Return styled badge HTML for token or user status.
 */
function getStatusBadge(status) {
    const map = {
        'WAITING': '<span class="badge-status badge-waiting"><i class="bi bi-clock-history"></i> Waiting</span>',
        'SERVING': '<span class="badge-status badge-serving"><i class="bi bi-broadcast"></i> Serving</span>',
        'COMPLETED': '<span class="badge-status badge-completed"><i class="bi bi-check-lg"></i> Completed</span>',
        'SKIPPED': '<span class="badge-status badge-skipped"><i class="bi bi-arrow-right-circle"></i> Skipped</span>',
        'CANCELLED': '<span class="badge-status badge-cancelled"><i class="bi bi-x-circle"></i> Cancelled</span>'
    };
    return map[status] || `<span class="badge-status badge-skipped">${status}</span>`;
}

/**
 * Format ISO datetime string to localized string.
 */
function formatDateTime(dtStr) {
    if (!dtStr) return '—';
    try {
        const d = new Date(dtStr.replace(' ', 'T'));
        return d.toLocaleString(undefined, {
            year: 'numeric',
            month: 'short',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        });
    } catch (e) {
        return dtStr;
    }
}

// Global mobile sidebar handler
document.addEventListener('DOMContentLoaded', () => {
    const toggleBtn = document.querySelector('.mobile-toggle');
    const sidebar = document.querySelector('.dashboard-sidebar');
    if (toggleBtn && sidebar) {
        toggleBtn.addEventListener('click', () => {
            sidebar.classList.toggle('show');
        });
        document.addEventListener('click', (e) => {
            if (!sidebar.contains(e.target) && !toggleBtn.contains(e.target) && sidebar.classList.contains('show')) {
                sidebar.classList.remove('show');
            }
        });
    }
});
