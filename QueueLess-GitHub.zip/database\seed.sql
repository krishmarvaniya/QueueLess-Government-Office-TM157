-- ===================================================
-- QueueLess Government Office - Seed Data
-- ===================================================

USE queueless;

-- 1. Insert Users
INSERT INTO users (id, full_name, email, mobile, password_hash, role, is_active, created_at) VALUES
(1, 'System Administrator', 'admin@example.com', '+91 9876543210', 'scrypt:32768:8:1$1hlwvv2Ji8eMTU2B$316acb6e13cf47e090be2e953ef49c17bc76295c46b8098e009455b2998e2dba917abc00035957dde4f054b4a4bb42b8ee182c4185c7a971c58557effe1556df', 'admin', 1, NOW()),
(2, 'Senior Officer Sharma', 'officer@example.com', '+91 9876543211', 'scrypt:32768:8:1$5TsLm8FYHc3U59Pc$6668fa882dda5e0d88947dd521ba530491e88dc45b260f237be6deb40be77d10fe37f54303074d38078b7a142cef3532ad3f6cc46f62783593d372de240839dc', 'officer', 1, NOW()),
(3, 'Desk Officer Priya', 'officer2@example.com', '+91 9876543212', 'scrypt:32768:8:1$5TsLm8FYHc3U59Pc$6668fa882dda5e0d88947dd521ba530491e88dc45b260f237be6deb40be77d10fe37f54303074d38078b7a142cef3532ad3f6cc46f62783593d372de240839dc', 'officer', 1, NOW()),
(4, 'Rajesh Kumar (Citizen)', 'citizen@example.com', '+91 9876543213', 'scrypt:32768:8:1$MPxiyJjv6moQ83Dg$0f0f0ac646bf93ffb0db4bc086f10f0279e10a58f7ff154561adc09d5b754b9f05f452b26d435835c22a859953ed4e0ba176a1a3ac0a5269df4cd9d41e1e28be', 'citizen', 1, NOW()),
(5, 'Ananya Patel (Citizen)', 'citizen2@example.com', '+91 9876543214', 'scrypt:32768:8:1$MPxiyJjv6moQ83Dg$0f0f0ac646bf93ffb0db4bc086f10f0279e10a58f7ff154561adc09d5b754b9f05f452b26d435835c22a859953ed4e0ba176a1a3ac0a5269df4cd9d41e1e28be', 'citizen', 1, NOW())
ON DUPLICATE KEY UPDATE full_name=VALUES(full_name);

-- 2. Insert Offices
INSERT INTO offices (id, name, code, address, city, state, opening_time, closing_time, is_active, created_at) VALUES
(1, 'District Citizen Service Center', 'DCSC', 'Civic Center Complex, Central Wing, Sector 4', 'New Delhi', 'Delhi', '09:00:00', '17:00:00', 1, NOW()),
(2, 'Regional Passport Office', 'RPO', 'Bhikaji Cama Place, Ring Road', 'New Delhi', 'Delhi', '09:30:00', '16:30:00', 1, NOW()),
(3, 'Municipal Corporation Office', 'MCO', 'Town Hall, Chandni Chowk', 'New Delhi', 'Delhi', '09:00:00', '17:30:00', 1, NOW()),
(4, 'Revenue Department Office', 'RDO', 'Kapashera Administrative Block', 'New Delhi', 'Delhi', '10:00:00', '16:00:00', 1, NOW())
ON DUPLICATE KEY UPDATE name=VALUES(name);

-- 3. Insert Services
INSERT INTO services (id, office_id, name, code, description, average_service_time, is_active, created_at) VALUES
(1, 1, 'Certificate Application', 'CERT', 'General purpose domicile, residence and clearance certificates', 12, 1, NOW()),
(2, 1, 'Income Certificate', 'INC', 'Issuance and verification of annual family income certificate', 15, 1, NOW()),
(3, 1, 'Caste Certificate', 'CST', 'Caste and community category verification service', 18, 1, NOW()),
(4, 2, 'Fresh Passport Application', 'PASS-NEW', 'Document verification and biometric capture for new passports', 20, 1, NOW()),
(5, 2, 'Passport Renewal', 'PASS-REN', 'Renewal, booklet re-issue and address modification', 15, 1, NOW()),
(6, 2, 'Police Clearance Certificate', 'PCC', 'Verification for overseas travel and employment PCC', 10, 1, NOW()),
(7, 3, 'Birth Certificate', 'BIRTH', 'Registration and certified copy issuance of birth records', 10, 1, NOW()),
(8, 3, 'Death Certificate', 'DEATH', 'Registration and issue of municipal death certificates', 10, 1, NOW()),
(9, 3, 'Trade License Registration', 'TRADE', 'Commercial establishment and shop trade license verification', 25, 1, NOW()),
(10, 4, 'Land Record Verification', 'LAND', 'Khasra, Khatauni and ownership record verification', 20, 1, NOW()),
(11, 4, 'Property Tax Assessment', 'TAX', 'Assessment, mutation and property tax receipt processing', 15, 1, NOW())
ON DUPLICATE KEY UPDATE name=VALUES(name);

-- 4. Insert Counters
INSERT INTO counters (id, office_id, counter_number, assigned_officer_id, is_active) VALUES
(1, 1, 'Counter 1', 2, 1),
(2, 1, 'Counter 2', 3, 1),
(3, 1, 'Counter 3', NULL, 1),
(4, 2, 'Counter 1', NULL, 1),
(5, 2, 'Counter 2', NULL, 1),
(6, 3, 'Counter 1', NULL, 1),
(7, 4, 'Counter 1', NULL, 1)
ON DUPLICATE KEY UPDATE counter_number=VALUES(counter_number);

-- 5. Insert Sample Initial Active / Completed Tokens
INSERT INTO tokens (id, token_number, user_id, office_id, service_id, counter_id, status, queue_position, issued_at, called_at, completed_at, estimated_wait_minutes, recommended_arrival, qr_code_path, created_at) VALUES
(1, 'CERT-101', 5, 1, 1, 1, 'COMPLETED', 0, DATE_SUB(NOW(), INTERVAL 90 MINUTE), DATE_SUB(NOW(), INTERVAL 75 MINUTE), DATE_SUB(NOW(), INTERVAL 60 MINUTE), 15, DATE_SUB(NOW(), INTERVAL 80 MINUTE), NULL, DATE_SUB(NOW(), INTERVAL 90 MINUTE)),
(2, 'CERT-102', 5, 1, 1, 1, 'SERVING', 0, DATE_SUB(NOW(), INTERVAL 45 MINUTE), DATE_SUB(NOW(), INTERVAL 10 MINUTE), NULL, 12, DATE_SUB(NOW(), INTERVAL 20 MINUTE), NULL, DATE_SUB(NOW(), INTERVAL 45 MINUTE)),
(3, 'CERT-103', 4, 1, 1, NULL, 'WAITING', 1, DATE_SUB(NOW(), INTERVAL 20 MINUTE), NULL, NULL, 12, DATE_ADD(NOW(), INTERVAL 2 MINUTE), NULL, DATE_SUB(NOW(), INTERVAL 20 MINUTE))
ON DUPLICATE KEY UPDATE token_number=VALUES(token_number);

-- 6. Insert Notifications
INSERT INTO notifications (id, user_id, token_id, title, message, type, is_read, created_at) VALUES
(1, 4, 3, 'Token Generated', 'Your token CERT-103 has been created successfully for Certificate Application at District Citizen Service Center.', 'success', 0, DATE_SUB(NOW(), INTERVAL 20 MINUTE)),
(2, 4, 3, 'Turn Approaching', 'Your turn is approaching! You are currently position 1 in queue. Please reach the office premises.', 'warning', 0, DATE_SUB(NOW(), INTERVAL 5 MINUTE))
ON DUPLICATE KEY UPDATE title=VALUES(title);

-- 7. Insert Audit Logs
INSERT INTO audit_logs (id, user_id, action, entity_type, entity_id, details, created_at) VALUES
(1, 1, 'SYSTEM_INIT', 'SYSTEM', 1, 'Initial database tables created and seeded.', NOW()),
(2, 2, 'OFFICER_ASSIGNED', 'COUNTER', 1, 'Officer Senior Sharma assigned to Counter 1 at DCSC.', NOW())
ON DUPLICATE KEY UPDATE action=VALUES(action);

-- 8. Seed Sample Prediction History
INSERT INTO prediction_history (id, token_id, queue_length, people_ahead, active_counters, average_service_time, hour, day_of_week, predicted_wait, actual_wait, created_at) VALUES
(1, 1, 2, 1, 1, 12, 10, 2, 14.5, 15.0, DATE_SUB(NOW(), INTERVAL 90 MINUTE)),
(2, 2, 3, 2, 1, 12, 11, 2, 24.0, NULL, DATE_SUB(NOW(), INTERVAL 45 MINUTE)),
(3, 3, 2, 1, 1, 12, 11, 2, 12.0, NULL, DATE_SUB(NOW(), INTERVAL 20 MINUTE))
ON DUPLICATE KEY UPDATE queue_length=VALUES(queue_length);
