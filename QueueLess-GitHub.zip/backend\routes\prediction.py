from flask import Blueprint, request
from backend.models.token import Token
from backend.models.service import Service
from backend.models.counter import Counter
from backend.prediction.predictor import predict_wait_time
from backend.utils.decorators import success_response, error_response

prediction_bp = Blueprint('prediction', __name__, url_prefix='/api/prediction')

@prediction_bp.route('/<int:token_id>', methods=['GET'])
def get_token_prediction(token_id):
    token = Token.query.get(token_id)
    if not token:
        return error_response("Token not found", "NOT_FOUND", 404)

    # Calculate people ahead
    if token.status == 'WAITING':
        people_ahead = Token.query.filter(
            Token.office_id == token.office_id,
            Token.service_id == token.service_id,
            Token.status == 'WAITING',
            Token.issued_at < token.issued_at
        ).count()
    else:
        people_ahead = 0

    queue_length = Token.query.filter_by(
        office_id=token.office_id,
        service_id=token.service_id,
        status='WAITING'
    ).count()

    active_counters = Counter.query.filter_by(office_id=token.office_id, is_active=True).count()
    avg_service_time = token.service.average_service_time if token.service else 15

    result = predict_wait_time(
        queue_length=queue_length,
        people_ahead=people_ahead,
        active_counters=active_counters,
        average_service_time=avg_service_time
    )

    return success_response({
        'token_id': token.id,
        'token_number': token.token_number,
        'status': token.status,
        'prediction': result
    }, "Prediction fetched", 200)

@prediction_bp.route('/estimate', methods=['POST'])
def estimate_service_wait():
    data = request.get_json() or {}
    office_id = data.get('office_id')
    service_id = data.get('service_id')

    if not office_id or not service_id:
        return error_response("office_id and service_id are required", "VALIDATION_ERROR", 400)

    service = Service.query.get(service_id)
    if not service:
        return error_response("Service not found", "NOT_FOUND", 404)

    waiting_count = Token.query.filter_by(
        office_id=office_id,
        service_id=service_id,
        status='WAITING'
    ).count()

    active_counters = Counter.query.filter_by(office_id=office_id, is_active=True).count()

    result = predict_wait_time(
        queue_length=waiting_count,
        people_ahead=waiting_count,
        active_counters=active_counters,
        average_service_time=service.average_service_time
    )

    return success_response({
        'office_id': office_id,
        'service_id': service_id,
        'service_name': service.name,
        'people_waiting': waiting_count,
        'active_counters': active_counters,
        'estimated_wait_minutes': result['predicted_wait_minutes'],
        'method': result['method'],
        'is_ml': result['is_ml']
    }, "Queue estimate calculated", 200)
