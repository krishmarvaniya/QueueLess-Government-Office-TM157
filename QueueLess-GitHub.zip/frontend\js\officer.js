/* ===================================================
   QueueLess Government Office - Officer Operations
   =================================================== */

const OfficerApp = {
    currentStatus: null,
    allCounters: [],
    allQueueTokens: [],
    pollInterval: null,
    POLL_MS: 8000,

    async init() {
        // Reset TTS dedup so stale tokens are never auto-announced on page load/refresh
        if (typeof VoiceAnnouncer !== 'undefined') VoiceAnnouncer.reset();

        // Start socket if available
        SocketManager.init();

        // First load everything
        await this.loadStatus();
        await this.loadDashboardData();

        // Listen for real-time queue updates
        if (SocketManager.socket) {
            SocketManager.socket.on('queue_update', (snapshot) => {
                if (this.currentStatus && this.currentStatus.counter &&
                    snapshot.office_id === this.currentStatus.counter.office_id) {
                    this.loadStatus(false);
                    this.loadDashboardData(false);
                }
            });
            SocketManager.socket.on('call_announcement', () => {
                this.loadStatus(false);
                this.loadDashboardData(false);
            });
        }

        // Polling fallback for real-time updates
        this.pollInterval = setInterval(() => {
            this.loadStatus(false);
            this.loadDashboardData(false);
        }, this.POLL_MS);
    },

    /* ───── My Counter Status ───── */

    async loadStatus(showLoading = true) {
        try {
            const res = await API.get('/officer/status');
            if (res.success && res.data) {
                this.currentStatus = res.data;
                this.renderMyCounter(res.data);
                if (res.data.counter) {
                    SocketManager.joinOfficeRoom(res.data.counter.office_id);
                }
            }
        } catch (err) {
            showToast('error', 'Error', 'Failed to load officer terminal status');
        }
    },

    renderMyCounter(data) {
        const counter = data.counter;
        const currentToken = data.current_token;
        const nextToken = data.next_token;

        // Top-bar label
        const counterNameEl = document.getElementById('officer-counter-name');
        if (counterNameEl) {
            counterNameEl.textContent = counter
                ? `${counter.counter_number} — ${counter.office_name || 'Office'}`
                : 'Unassigned';
        }

        // Stats
        const waitEl = document.getElementById('officer-waiting-count');
        if (waitEl) waitEl.textContent = data.waiting_count ?? '—';

        const avgEl = document.getElementById('officer-avg-service');
        if (avgEl) avgEl.textContent = `${data.average_service_time ?? '—'} min`;

        const doneEl = document.getElementById('officer-completed-count');
        if (doneEl) doneEl.textContent = data.completed_today_count ?? '—';

        // Serving Box
        const servingBox = document.getElementById('officer-serving-box');
        if (servingBox) {
            if (currentToken) {
                servingBox.innerHTML = `
                    <div class="officer-control-box fade-in">
                        <span class="badge bg-success px-3 py-2 mb-2">NOW SERVING</span>
                        <div class="officer-serving-number">${escapeHtml(currentToken.token_number)}</div>
                        <h4 class="text-white mb-1">${escapeHtml(currentToken.citizen_name || 'Citizen')}</h4>
                        <div class="text-info mb-3">Service: ${escapeHtml(currentToken.service_name)}</div>
                        <div class="officer-actions-grid">
                            <button class="btn btn-success btn-lg" onclick="OfficerApp.completeToken(${currentToken.id})">
                                <i class="bi bi-check-circle me-1"></i> COMPLETE
                            </button>
                            <button class="btn btn-warning btn-lg text-dark" onclick="OfficerApp.recallToken(${currentToken.id})">
                                <i class="bi bi-volume-up me-1"></i> RECALL
                            </button>
                            <button class="btn btn-secondary btn-lg" onclick="OfficerApp.skipToken(${currentToken.id})">
                                <i class="bi bi-arrow-right-circle me-1"></i> SKIP
                            </button>
                        </div>
                    </div>
                `;
            } else {
                servingBox.innerHTML = `
                    <div class="officer-control-box fade-in bg-dark">
                        <span class="badge bg-secondary px-3 py-2 mb-2">COUNTER IDLE</span>
                        <div class="officer-serving-number text-muted">---</div>
                        <p class="text-muted">No token is currently being served at your counter.</p>
                        <div class="mt-3">
                            <button class="btn btn-primary btn-lg px-4" id="btn-call-next" onclick="OfficerApp.callNext()">
                                <i class="bi bi-megaphone me-1"></i> CALL NEXT TOKEN
                            </button>
                        </div>
                    </div>
                `;
            }
        }

        // Next-in-line preview
        const nextPreviewEl = document.getElementById('officer-next-preview');
        if (nextPreviewEl) {
            if (nextToken) {
                nextPreviewEl.innerHTML = `
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <div class="fw-bold fs-5 text-primary">${escapeHtml(nextToken.token_number)}</div>
                            <small class="text-muted">${escapeHtml(nextToken.service_name)} — ${escapeHtml(nextToken.citizen_name || 'Citizen')}</small>
                        </div>
                        <span class="badge bg-warning text-dark">Position #1</span>
                    </div>
                `;
            } else {
                nextPreviewEl.innerHTML = `<span class="text-muted">Queue is currently empty.</span>`;
            }
        }
    },

    /* ───── All Counters + Full Queue ───── */

    async loadDashboardData(showLoading = true) {
        try {
            const res = await API.get('/officer/dashboard-data');
            if (res.success && res.data) {
                this.allCounters = res.data.all_counters || [];
                this.allQueueTokens = res.data.waiting_tokens || [];
                this.renderAllCounters(this.allCounters);
                this.populateFilters();
                this.renderQueueTable(this.allQueueTokens);
            }
        } catch (err) {
            // Silently fail on polling; only show error on initial load
            if (showLoading) {
                const grid = document.getElementById('all-counters-grid');
                if (grid) grid.innerHTML = `<div class="col-12"><div class="alert alert-danger">Failed to load counters. <button class="btn btn-sm btn-outline-danger ms-2" onclick="OfficerApp.loadDashboardData()">Retry</button></div></div>`;
            }
        }
    },

    renderAllCounters(counters) {
        const grid = document.getElementById('all-counters-grid');
        if (!grid) return;

        if (!counters.length) {
            grid.innerHTML = `<div class="col-12 text-center text-muted py-4"><i class="bi bi-inbox fs-3 d-block mb-2"></i>No active counters found for this office.</div>`;
            return;
        }

        // Identify the officer's own counter
        const myCounterId = this.currentStatus?.counter?.id;

        grid.innerHTML = counters.map(c => {
            const isMine = c.id === myCounterId;
            const statusClass = c.status === 'SERVING' ? 'serving' : c.status === 'PAUSED' ? 'paused' : 'idle';
            const dotClass   = c.status === 'SERVING' ? 'dot-serving' : c.status === 'PAUSED' ? 'dot-paused' : 'dot-idle';

            const servingTokenHtml = c.current_token
                ? `<div class="counter-token-big">${escapeHtml(c.current_token.token_number)}</div>
                   <div class="text-muted small mt-1">${escapeHtml(c.current_token.citizen_name || 'Citizen')} — ${escapeHtml(c.current_token.service_name)}</div>`
                : `<div class="counter-token-big idle-token">— — —</div>
                   <div class="text-muted small mt-1">No token being served</div>`;

            const nextHtml = c.next_token
                ? `<div class="counter-next-label">Next Token</div>
                   <div class="counter-next-value">${escapeHtml(c.next_token.token_number)}</div>
                   <div class="text-muted" style="font-size:.75rem">${escapeHtml(c.next_token.service_name)}</div>`
                : `<div class="counter-next-label">Next Token</div>
                   <div class="text-muted small">Queue empty</div>`;

            const estimatedWait = c.estimated_wait > 0
                ? `${c.estimated_wait} min`
                : '—';

            const myBadge = isMine
                ? `<span class="badge bg-primary" style="font-size:.65rem">Your Counter</span>`
                : '';

            const actionHtml = isMine ? `
                <div class="counter-actions">
                    ${c.status === 'SERVING'
                        ? `<button class="btn btn-sm btn-success" onclick="OfficerApp.completeToken(${c.current_token.id})"><i class="bi bi-check-circle me-1"></i>Complete</button>
                           <button class="btn btn-sm btn-warning text-dark" onclick="OfficerApp.recallToken(${c.current_token.id})"><i class="bi bi-volume-up me-1"></i>Recall</button>
                           <button class="btn btn-sm btn-secondary" onclick="OfficerApp.skipToken(${c.current_token.id})"><i class="bi bi-arrow-right-circle me-1"></i>Skip</button>`
                        : `<button class="btn btn-sm btn-primary" onclick="OfficerApp.callNext()"><i class="bi bi-megaphone me-1"></i>Call Next</button>`
                    }
                </div>` : '';

            return `
                <div class="col-md-6 col-xl-4">
                    <div class="counter-card ${statusClass}">
                        <div class="counter-card-header">
                            <div>
                                <div class="counter-number-label">Counter</div>
                                <div class="counter-name">${escapeHtml(c.counter_number)} ${myBadge}</div>
                            </div>
                            <div class="d-flex flex-column align-items-end gap-1">
                                <span class="status-dot ${dotClass}"></span>
                                <span class="badge badge-${c.status.toLowerCase()}" style="font-size:.72rem">${c.status}</span>
                            </div>
                        </div>
                        <div class="counter-card-body">
                            <div class="text-muted small fw-semibold text-uppercase mb-1" style="font-size:.65rem; letter-spacing:.04em">Currently Serving</div>
                            ${servingTokenHtml}
                            <div class="counter-stat-row">
                                <div class="counter-stat">
                                    <strong>${c.citizens_waiting ?? 0}</strong>
                                    Waiting
                                </div>
                                <div class="counter-stat">
                                    <strong>NEXT AT ${escapeHtml(c.counter_number)}: ${c.next_token ? escapeHtml(c.next_token.token_number) : '—'}</strong>
                                    Est. ${estimatedWait}
                                </div>
                            </div>
                            <div class="counter-next-row mt-2">
                                ${nextHtml}
                            </div>
                            <div class="counter-officer-row">
                                <i class="bi bi-person-badge"></i>
                                <span>${escapeHtml(c.officer_name || 'Unassigned')}</span>
                            </div>
                        </div>
                        ${actionHtml}
                    </div>
                </div>
            `;
        }).join('');
    },

    populateFilters() {
        // Counter filter
        const counterSelect = document.getElementById('filter-counter');
        if (counterSelect && this.allCounters.length) {
            const existing = [...counterSelect.options].map(o => o.value);
            this.allCounters.forEach(c => {
                if (!existing.includes(String(c.id))) {
                    const opt = document.createElement('option');
                    opt.value = c.id;
                    opt.textContent = `${c.counter_number}`;
                    counterSelect.appendChild(opt);
                }
            });
        }

        // Service filter
        const serviceSelect = document.getElementById('filter-service');
        if (serviceSelect && this.allQueueTokens.length) {
            const seen = new Set([...serviceSelect.options].map(o => o.value));
            this.allQueueTokens.forEach(t => {
                if (t.service_id && !seen.has(String(t.service_id))) {
                    seen.add(String(t.service_id));
                    const opt = document.createElement('option');
                    opt.value = t.service_id;
                    opt.textContent = t.service_name;
                    serviceSelect.appendChild(opt);
                }
            });
        }
    },

    applyFilters() {
        const counterVal = document.getElementById('filter-counter')?.value;
        const statusVal  = document.getElementById('filter-status')?.value;
        const serviceVal = document.getElementById('filter-service')?.value;

        let filtered = this.allQueueTokens;
        if (counterVal) filtered = filtered.filter(t => String(t.counter_id) === counterVal || (!t.counter_id && counterVal === 'unassigned'));
        if (statusVal)  filtered = filtered.filter(t => t.status === statusVal);
        if (serviceVal) filtered = filtered.filter(t => String(t.service_id) === serviceVal);

        this.renderQueueTable(filtered);
    },

    clearFilters() {
        document.getElementById('filter-counter').value = '';
        document.getElementById('filter-status').value  = '';
        document.getElementById('filter-service').value = '';
        this.renderQueueTable(this.allQueueTokens);
    },

    renderQueueTable(tokens) {
        const tbody = document.getElementById('queue-tbody');
        if (!tbody) return;

        if (!tokens.length) {
            tbody.innerHTML = `<tr><td colspan="9" class="text-center text-muted py-4"><i class="bi bi-inbox fs-3 d-block mb-2"></i>No tokens in queue.</td></tr>`;
            return;
        }

        // Build per-counter "next token" map from allCounters
        const nextAtCounter = {};
        this.allCounters.forEach(c => {
            if (c.next_token) nextAtCounter[c.next_token.id] = c.counter_number;
        });

        tbody.innerHTML = tokens.map((t, idx) => {
            const statusBadge = this.statusBadge(t.status);
            const isNext = nextAtCounter[t.id];
            const nextActionHtml = isNext
                ? `<span class="next-indicator"><i class="bi bi-arrow-right-circle-fill me-1"></i>NEXT AT ${escapeHtml(isNext)}</span>`
                : (t.status === 'SERVING'
                    ? `<span class="badge badge-serving">In Service</span>`
                    : `<span class="text-muted small">Waiting</span>`);

            const wait = t.estimated_wait_minutes > 0
                ? `${t.estimated_wait_minutes} min`
                : (t.status === 'SERVING' ? '<span class="text-success small">Now serving</span>' : '—');

            return `
                <tr class="${t.status === 'SERVING' ? 'table-success' : ''}">
                    <td class="ps-3 text-muted small">${idx + 1}</td>
                    <td class="fw-bold">${escapeHtml(t.token_number)}</td>
                    <td>${escapeHtml(t.citizen_name || '—')}</td>
                    <td class="small">${escapeHtml(t.service_name || '—')}</td>
                    <td class="small">${t.counter_number ? escapeHtml(t.counter_number) : '<span class="text-muted">Unassigned</span>'}</td>
                    <td class="small">${escapeHtml(t.counter_id && this.allCounters.find(c=>c.id===t.counter_id)?.officer_name || '—')}</td>
                    <td>${statusBadge}</td>
                    <td class="small">${wait}</td>
                    <td>${nextActionHtml}</td>
                </tr>
            `;
        }).join('');
    },

    statusBadge(status) {
        const map = {
            'WAITING':   `<span class="badge badge-waiting">Waiting</span>`,
            'SERVING':   `<span class="badge badge-serving">Serving</span>`,
            'COMPLETED': `<span class="badge badge-completed">Completed</span>`,
            'SKIPPED':   `<span class="badge badge-skipped">Skipped</span>`,
            'CANCELLED': `<span class="badge badge-cancelled">Cancelled</span>`,
        };
        return map[status] || `<span class="badge bg-secondary">${escapeHtml(status)}</span>`;
    },

    refreshAll() {
        this.loadStatus(false);
        this.loadDashboardData(false);
    },

    /* ───── Token Actions ───── */

    async callNext() {
        const btn = document.getElementById('btn-call-next');
        if (btn) setButtonLoading(btn, true, 'Calling Next...');
        try {
            const res = await API.post('/officer/next', {});
            if (res.success && res.data) {
                showToast('success', 'Token Called', `Token ${res.data.token_number} called to your counter!`);
                // Announce the newly called token (deduplication: same token won't repeat via polling)
                if (typeof VoiceAnnouncer !== 'undefined') {
                    VoiceAnnouncer.announceNew(
                        res.data.token_number,
                        res.data.counter_number || this.currentStatus?.counter?.counter_number,
                        res.data.id
                    );
                }
                await this.loadStatus(false);
                await this.loadDashboardData(false);
            }
        } catch (err) {
            showToast('error', 'Unable to Call', err.message || 'Error calling next token');
        } finally {
            const btn2 = document.getElementById('btn-call-next');
            if (btn2) setButtonLoading(btn2, false);
        }
    },

    async completeToken(tokenId) {
        if (!confirm('Mark service as COMPLETED for this token?')) return;
        try {
            const res = await API.post(`/officer/token/${tokenId}/complete`, {});
            if (res.success) {
                showToast('success', 'Completed', 'Token marked as completed.');
                await this.loadStatus(false);
                await this.loadDashboardData(false);
            }
        } catch (err) {
            showToast('error', 'Error', err.message || 'Failed to complete token');
        }
    },

    async skipToken(tokenId) {
        if (!confirm('Are you sure you want to SKIP this token?')) return;
        try {
            const res = await API.post(`/officer/token/${tokenId}/skip`, {});
            if (res.success) {
                showToast('warning', 'Skipped', 'Token marked as skipped.');
                await this.loadStatus(false);
                await this.loadDashboardData(false);
            }
        } catch (err) {
            showToast('error', 'Error', err.message || 'Failed to skip token');
        }
    },

    async recallToken(tokenId) {
        try {
            const res = await API.post(`/officer/token/${tokenId}/recall`, {});
            if (res.success) {
                showToast('info', 'Token Recalled', 'Token re-announced across display boards.');
                // Always speak on recall — intentional click bypasses dedup
                if (typeof VoiceAnnouncer !== 'undefined') {
                    const t = res.data;
                    VoiceAnnouncer.recall(t.token_number, t.counter_number || this.currentStatus?.counter?.counter_number);
                }
            }
        } catch (err) {
            showToast('error', 'Error', err.message || 'Failed to recall token');
        }
    }
};
