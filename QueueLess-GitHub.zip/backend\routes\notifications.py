from flask import Blueprint, g
from backend.extensions import db
from backend.models.notification import Notification
from backend.utils.decorators import success_response, error_response, login_required

notifications_bp = Blueprint('notifications', __name__, url_prefix='/api/notifications')

@notifications_bp.route('', methods=['GET'])
@login_required
def get_user_notifications():
    notifications = Notification.query.filter_by(
        user_id=g.current_user.id
    ).order_by(Notification.created_at.desc()).limit(50).all()

    unread_count = Notification.query.filter_by(
        user_id=g.current_user.id,
        is_read=False
    ).count()

    return success_response({
        'notifications': [n.to_dict() for n in notifications],
        'unread_count': unread_count
    }, "Notifications retrieved", 200)

@notifications_bp.route('/<int:notification_id>/read', methods=['PUT'])
@login_required
def mark_notification_read(notification_id):
    notif = Notification.query.get(notification_id)
    if not notif:
        return error_response("Notification not found", "NOT_FOUND", 404)

    if notif.user_id != g.current_user.id:
        return error_response("Unauthorized", "FORBIDDEN", 403)

    notif.is_read = True
    db.session.commit()
    return success_response(notif.to_dict(), "Notification marked as read", 200)

@notifications_bp.route('/read-all', methods=['PUT'])
@login_required
def mark_all_read():
    Notification.query.filter_by(user_id=g.current_user.id, is_read=False).update({'is_read': True})
    db.session.commit()
    return success_response(None, "All notifications marked as read", 200)
