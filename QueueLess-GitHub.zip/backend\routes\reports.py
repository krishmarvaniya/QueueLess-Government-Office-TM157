from datetime import datetime, date, timedelta
from flask import Blueprint, request
from sqlalchemy import func
from backend.models.token import Token
from backend.models.service import Service
from backend.models.office import Office
from backend.utils.decorators import success_response, roles_required

reports_bp = Blueprint('reports', __name__, url_prefix='/api/reports')

@reports_bp.route('/daily', methods=['GET'])
@roles_required('admin')
def daily_report():
    date_str = request.args.get('date')
    office_id = request.args.get('office_id', type=int)

    if date_str:
        try:
            target_date = datetime.strptime(date_str, '%Y-%m-%d').date()
        except ValueError:
            target_date = date.today()
    else:
        target_date = date.today()

    start_dt = datetime.combine(target_date, datetime.min.time())
    end_dt = datetime.combine(target_date, datetime.max.time())

    query = Token.query.filter(Token.created_at.between(start_dt, end_dt))
    if office_id:
        query = query.filter(Token.office_id == office_id)

    tokens = query.all()

    total = len(tokens)
    completed = len([t for t in tokens if t.status == 'COMPLETED'])
    cancelled = len([t for t in tokens if t.status == 'CANCELLED'])
    skipped = len([t for t in tokens if t.status == 'SKIPPED'])
    waiting = len([t for t in tokens if t.status == 'WAITING'])
    serving = len([t for t in tokens if t.status == 'SERVING'])

    wait_times = []
    service_times = []
    for t in tokens:
        if t.issued_at and t.called_at:
            wait_times.append((t.called_at - t.issued_at).total_seconds() / 60.0)
        if t.called_at and t.completed_at:
            service_times.append((t.completed_at - t.called_at).total_seconds() / 60.0)

    avg_wait = round(sum(wait_times) / len(wait_times), 1) if wait_times else 0.0
    avg_service = round(sum(service_times) / len(service_times), 1) if service_times else 0.0

    return success_response({
        'date': target_date.strftime('%Y-%m-%d'),
        'total_tokens': total,
        'completed': completed,
        'cancelled': cancelled,
        'skipped': skipped,
        'waiting': waiting,
        'serving': serving,
        'average_wait_minutes': avg_wait,
        'average_service_minutes': avg_service
    }, "Daily report generated", 200)

@reports_bp.route('/weekly', methods=['GET'])
@roles_required('admin')
def weekly_report():
    office_id = request.args.get('office_id', type=int)
    today = date.today()
    days_data = []

    for i in range(6, -1, -1):
        d = today - timedelta(days=i)
        start_dt = datetime.combine(d, datetime.min.time())
        end_dt = datetime.combine(d, datetime.max.time())

        query = Token.query.filter(Token.created_at.between(start_dt, end_dt))
        if office_id:
            query = query.filter(Token.office_id == office_id)

        tokens = query.all()
        wait_times = [
            (t.called_at - t.issued_at).total_seconds() / 60.0
            for t in tokens if t.issued_at and t.called_at
        ]
        avg_wait = round(sum(wait_times) / len(wait_times), 1) if wait_times else 0.0

        days_data.append({
            'date': d.strftime('%Y-%m-%d'),
            'day_name': d.strftime('%a'),
            'total_tokens': len(tokens),
            'completed': len([t for t in tokens if t.status == 'COMPLETED']),
            'average_wait_minutes': avg_wait
        })

    return success_response({
        'week_range': f"{(today - timedelta(days=6)).strftime('%Y-%m-%d')} to {today.strftime('%Y-%m-%d')}",
        'daily_breakdown': days_data
    }, "Weekly report generated", 200)

@reports_bp.route('/monthly', methods=['GET'])
@roles_required('admin')
def monthly_report():
    office_id = request.args.get('office_id', type=int)
    today = date.today()
    start_dt = datetime.combine(today - timedelta(days=30), datetime.min.time())

    query = Token.query.filter(Token.created_at >= start_dt)
    if office_id:
        query = query.filter(Token.office_id == office_id)

    tokens = query.all()

    # Service performance
    service_stats = {}
    for t in tokens:
        sname = t.service.name if t.service else "Other"
        if sname not in service_stats:
            service_stats[sname] = {'count': 0, 'completed': 0}
        service_stats[sname]['count'] += 1
        if t.status == 'COMPLETED':
            service_stats[sname]['completed'] += 1

    # Office performance
    offices = Office.query.all()
    office_stats = []
    for off in offices:
        off_tokens = [t for t in tokens if t.office_id == off.id]
        office_stats.append({
            'office_name': off.name,
            'total_tokens': len(off_tokens),
            'completed': len([t for t in off_tokens if t.status == 'COMPLETED'])
        })

    return success_response({
        'total_tokens_30d': len(tokens),
        'service_performance': service_stats,
        'office_performance': office_stats
    }, "Monthly report generated", 200)
