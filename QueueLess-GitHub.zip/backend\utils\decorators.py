from functools import wraps
from flask import request, jsonify, g, session
from backend.models.user import User
from backend.utils.auth import decode_auth_token

def success_response(data=None, message="Success", status_code=200):
    response = {
        'success': True,
        'message': message,
        'data': data if data is not None else {}
    }
    return jsonify(response), status_code

def error_response(message="Operation failed", error_code="ERROR", status_code=400, details=None):
    response = {
        'success': False,
        'message': message,
        'error': error_code
    }
    if details:
        response['details'] = details
    return jsonify(response), status_code

def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        user = None
        auth_header = request.headers.get('Authorization')
        
        # Check Bearer token in header
        if auth_header and auth_header.startswith('Bearer '):
            token = auth_header.split(' ', 1)[1].strip()
            payload = decode_auth_token(token)
            if payload and 'user_id' in payload:
                user = User.query.get(payload['user_id'])

        # Fallback to Flask session
        if not user and 'user_id' in session:
            user = User.query.get(session['user_id'])

        if not user or not user.is_active:
            return error_response("Authentication required or account deactivated", "UNAUTHORIZED", 401)

        g.current_user = user
        return f(*args, **kwargs)
    return decorated_function

def roles_required(*allowed_roles):
    def decorator(f):
        @wraps(f)
        @login_required
        def decorated_function(*args, **kwargs):
            if g.current_user.role not in allowed_roles:
                return error_response("You do not have permission to access this resource", "FORBIDDEN", 403)
            return f(*args, **kwargs)
        return decorated_function
    return decorator
