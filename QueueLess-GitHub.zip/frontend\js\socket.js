/* ===================================================
   QueueLess Government Office - Socket.IO Manager
   =================================================== */

const SocketManager = {
    socket: null,
    connected: false,

    init() {
        if (typeof io === 'undefined') {
            console.warn('Socket.IO client library not loaded.');
            return null;
        }

        if (this.socket) {
            return this.socket;
        }

        try {
            this.socket = io({
                transports: ['websocket', 'polling'],
                reconnectionAttempts: 10,
                reconnectionDelay: 1000
            });

            this.socket.on('connect', () => {
                this.connected = true;
                console.log('Socket.IO connected. ID:', this.socket.id);

                const user = API.getCurrentUser();
                if (user && user.id) {
                    this.joinUserRoom(user.id);
                }
            });

            this.socket.on('disconnect', () => {
                this.connected = false;
                console.log('Socket.IO disconnected.');
            });

            this.socket.on('call_announcement', (data) => {
                this.playChime();
                showToast(
                    'info',
                    `Token Called: ${data.token_number}`,
                    `Proceed immediately to ${data.counter_number} (${data.service_name})`,
                    7000
                );
            });

            return this.socket;
        } catch (e) {
            console.error('Socket init error:', e);
            return null;
        }
    },

    joinOfficeRoom(officeId) {
        if (this.socket && officeId) {
            this.socket.emit('join_office', { office_id: officeId });
        }
    },

    leaveOfficeRoom(officeId) {
        if (this.socket && officeId) {
            this.socket.emit('leave_office', { office_id: officeId });
        }
    },

    joinUserRoom(userId) {
        if (this.socket && userId) {
            this.socket.emit('join_user', { user_id: userId });

            // Listen to personalized notifications
            this.socket.on(`notification_${userId}`, (notif) => {
                this.playChime();
                showToast(notif.type || 'info', notif.title, notif.message, 6000);

                // Update notification badge count if present
                const badge = document.querySelector('.notification-count-badge');
                if (badge) {
                    let count = parseInt(badge.textContent || '0') + 1;
                    badge.textContent = count;
                    badge.style.display = 'inline-block';
                }
            });
        }
    },

    joinTokenRoom(tokenId, callback) {
        if (this.socket && tokenId) {
            this.socket.emit('join_token', { token_id: tokenId });
            this.socket.on(`token_${tokenId}`, (token) => {
                if (typeof callback === 'function') {
                    callback(token);
                }
            });
        }
    },

    /**
     * Synthesizes audio chime using Web Audio API
     */
    playChime() {
        try {
            const ctx = new (window.AudioContext || window.webkitAudioContext)();
            const osc = ctx.createOscillator();
            const gain = ctx.createGain();

            osc.type = 'sine';
            osc.frequency.setValueAtTime(587.33, ctx.currentTime); // D5
            osc.frequency.setValueAtTime(880.00, ctx.currentTime + 0.12); // A5

            gain.gain.setValueAtTime(0.2, ctx.currentTime);
            gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.6);

            osc.connect(gain);
            gain.connect(ctx.destination);

            osc.start();
            osc.stop(ctx.currentTime + 0.6);
        } catch (e) {
            // Audio context might require user interaction first
        }
    }
};
