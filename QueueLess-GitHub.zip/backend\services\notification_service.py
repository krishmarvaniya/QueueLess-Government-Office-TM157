from backend.extensions import db, socketio
from backend.models.notification import Notification

def create_notification(user_id: int, title: str, message: str, notification_type: str = 'info', token_id: int = None):
    """
    Persist notification to DB and emit real-time event to user socket room.
    """
    try:
        notif = Notification(
            user_id=user_id,
            token_id=token_id,
            title=title,
            message=message,
            type=notification_type,
            is_read=False
        )
        db.session.add(notif)
        db.session.flush()

        notif_dict = notif.to_dict()

        # Emit to user specific room / channel
        socketio.emit(f'notification_{user_id}', notif_dict)
        socketio.emit('new_notification', notif_dict, room=f'user_{user_id}')

        return notif
    except Exception as e:
        print(f"Failed to create notification: {e}")
        return None

def notify_token_created(token):
    msg = f"Your token {token.token_number} has been created successfully for {token.service.name} at {token.office.name}."
    return create_notification(
        user_id=token.user_id,
        title="Token Generated",
        message=msg,
        notification_type="success",
        token_id=token.id
    )

def notify_queue_updated(token, people_ahead: int, queue_position: int):
    title = "Queue Position Updated"
    msg = f"Your queue position is now {queue_position}. People ahead: {people_ahead}."
    return create_notification(
        user_id=token.user_id,
        title=title,
        message=msg,
        notification_type="info",
        token_id=token.id
    )

def notify_turn_approaching(token, people_ahead: int):
    title = "Your Turn is Approaching"
    msg = f"Your turn is approaching! Only {people_ahead} {'person is' if people_ahead == 1 else 'people are'} ahead. Please prepare your documents."
    return create_notification(
        user_id=token.user_id,
        title=title,
        message=msg,
        notification_type="warning",
        token_id=token.id
    )

def notify_serving(token, counter_number: str):
    title = "Now Serving"
    msg = f"Your token {token.token_number} is now being served! Please proceed immediately to {counter_number}."
    return create_notification(
        user_id=token.user_id,
        title=title,
        message=msg,
        notification_type="success",
        token_id=token.id
    )

def notify_completed(token):
    title = "Service Completed"
    msg = f"Your service for token {token.token_number} has been completed. Thank you for using QueueLess!"
    return create_notification(
        user_id=token.user_id,
        title=title,
        message=msg,
        notification_type="info",
        token_id=token.id
    )

def notify_skipped(token):
    title = "Token Skipped"
    msg = f"Your token {token.token_number} was marked as skipped. Please speak with the front help desk if you are present."
    return create_notification(
        user_id=token.user_id,
        title=title,
        message=msg,
        notification_type="alert",
        token_id=token.id
    )
