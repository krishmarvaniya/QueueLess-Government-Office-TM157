/* ===================================================
   QueueLess Government Office - Public Queue Monitor
   =================================================== */

const QueueMonitor = {
    selectedOfficeId: null,

    async init(officeId) {
        this.selectedOfficeId = officeId;
        SocketManager.init();

        await this.loadQueue(officeId);

        if (SocketManager.socket && officeId) {
            SocketManager.joinOfficeRoom(officeId);
            SocketManager.socket.on('queue_update', (snapshot) => {
                if (snapshot.office_id === this.selectedOfficeId) {
                    this.renderSnapshot(snapshot);
                }
            });
        }
    },

    async loadQueue(officeId) {
        if (!officeId) return;
        try {
            const res = await API.get(`/queue/${officeId}`);
            if (res.success && res.data) {
                this.renderSnapshot(res.data);
            }
        } catch (err) {
            console.error('Failed to load queue snapshot:', err);
        }
    },

    renderSnapshot(data) {
        // 1. Serving grid
        const servingContainer = document.getElementById('monitor-serving-grid');
        if (servingContainer) {
            if (!data.serving || data.serving.length === 0) {
                servingContainer.innerHTML = `
                    <div class="col-12 text-center text-muted py-4">
                        <i class="bi bi-pause-circle fs-3 d-block mb-1"></i>
                        No tokens are currently being served.
                    </div>
                `;
            } else {
                servingContainer.innerHTML = data.serving.map(t => `
                    <div class="col-md-6 col-lg-4 mb-3">
                        <div class="card border-primary text-center p-3 queue-highlight">
                            <span class="badge bg-primary text-uppercase mb-2">${escapeHtml(t.counter_number || 'Counter')}</span>
                            <div class="token-big-number my-1 text-primary">${escapeHtml(t.token_number)}</div>
                            <div class="small text-muted fw-bold">${escapeHtml(t.service_name)}</div>
                        </div>
                    </div>
                `).join('');
            }
        }

        // 2. Waiting List Table
        const waitingTbody = document.querySelector('#monitor-waiting-table tbody');
        if (waitingTbody) {
            if (!data.waiting || data.waiting.length === 0) {
                waitingTbody.innerHTML = `<tr><td colspan="5" class="text-center text-muted py-3">Queue is currently empty.</td></tr>`;
            } else {
                waitingTbody.innerHTML = data.waiting.map((t, idx) => `
                    <tr>
                        <td class="fw-bold">#${idx + 1}</td>
                        <td class="fw-bold text-primary">${escapeHtml(t.token_number)}</td>
                        <td>${escapeHtml(t.service_name)}</td>
                        <td><span class="badge bg-warning text-dark">${t.estimated_wait_minutes} min</span></td>
                        <td><span class="badge bg-light text-dark">${t.recommended_arrival || 'Soon'}</span></td>
                    </tr>
                `).join('');
            }
        }

        // 3. Stats
        const servingCountEl = document.getElementById('monitor-serving-count');
        if (servingCountEl) servingCountEl.textContent = data.serving_count;

        const waitingCountEl = document.getElementById('monitor-waiting-count');
        if (waitingCountEl) waitingCountEl.textContent = data.waiting_count;
    }
};
