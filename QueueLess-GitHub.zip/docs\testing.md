# QueueLess Government Office — Testing Guide

## 1. Automated Test Suite

The test suite is located in `tests/test_full_suite.py` and verifies all core application logic in an isolated SQLite memory database before connecting to MySQL.

### Test Categories
1. **Health Check**: Database ping and service responsiveness.
2. **Authentication & RBAC**:
   - Registration with duplicate email detection.
   - Login credential verification and password hashing.
   - Role-based authorization guarding admin routes against citizens.
3. **Queue & Token Engine**:
   - Sequential token numbering (e.g., `SRV-101`).
   - Duplicate active token prevention for the same service.
   - Public QR verification endpoint.
   - Officer FIFO calling (`WAITING` &rarr; `SERVING`).
   - Counter completion (`SERVING` &rarr; `COMPLETED`).
4. **Machine Learning Model & Fallback**:
   - Dynamic Random Forest predictions.
   - Zero queue condition handling.
   - Multi-counter throughput divisor validation.

### Running Tests

```bash
# Run full automated test suite with verbose output
python -m pytest tests/test_full_suite.py -v
```

All 8 core tests currently pass 100%.
