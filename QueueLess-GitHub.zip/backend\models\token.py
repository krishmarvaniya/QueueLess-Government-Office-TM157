from datetime import datetime
from backend.extensions import db

class Token(db.Model):
    __tablename__ = 'tokens'

    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    token_number = db.Column(db.String(30), nullable=False, index=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id', ondelete='CASCADE'), nullable=False, index=True)
    office_id = db.Column(db.Integer, db.ForeignKey('offices.id', ondelete='CASCADE'), nullable=False, index=True)
    service_id = db.Column(db.Integer, db.ForeignKey('services.id', ondelete='CASCADE'), nullable=False, index=True)
    counter_id = db.Column(db.Integer, db.ForeignKey('counters.id', ondelete='SET NULL'), nullable=True)
    officer_id = db.Column(db.Integer, db.ForeignKey('users.id', ondelete='SET NULL'), nullable=True)
    
    status = db.Column(
        db.Enum('WAITING', 'SERVING', 'COMPLETED', 'SKIPPED', 'CANCELLED', name='token_status'),
        nullable=False,
        default='WAITING',
        index=True
    )
    queue_position = db.Column(db.Integer, default=0)
    issued_at = db.Column(db.DateTime, default=datetime.utcnow)
    called_at = db.Column(db.DateTime, nullable=True)
    completed_at = db.Column(db.DateTime, nullable=True)
    cancelled_at = db.Column(db.DateTime, nullable=True)
    estimated_wait_minutes = db.Column(db.Integer, default=0)
    recommended_arrival = db.Column(db.DateTime, nullable=True)
    qr_code_path = db.Column(db.String(255), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    # Relationships
    notifications = db.relationship('Notification', backref='token', lazy='dynamic', cascade='all, delete-orphan')
    predictions = db.relationship('PredictionHistory', backref='token', lazy='dynamic', cascade='all, delete-orphan')

    def to_dict(self):
        return {
            'id': self.id,
            'token_number': self.token_number,
            'user_id': self.user_id,
            'citizen_name': self.user.full_name if self.user else None,
            'citizen_mobile': self.user.mobile if self.user else None,
            'citizen_email': self.user.email if self.user else None,
            'citizen_address': self.user.address if self.user else None,
            'citizen_city': self.user.city if self.user else None,
            'citizen_state': self.user.state if self.user else None,
            'citizen_pin_code': self.user.pin_code if self.user else None,
            'office_id': self.office_id,
            'office_name': self.office.name if self.office else None,
            'office_address': self.office.address if self.office else None,
            'service_id': self.service_id,
            'service_name': self.service.name if self.service else None,
            'service_code': self.service.code if self.service else None,
            'counter_id': self.counter_id,
            'counter_number': self.counter.counter_number if self.counter else None,
            'officer_id': self.officer_id,
            'status': self.status,
            'queue_position': self.queue_position,
            'issued_at': self.issued_at.strftime('%Y-%m-%d %H:%M:%S') if self.issued_at else None,
            'called_at': self.called_at.strftime('%Y-%m-%d %H:%M:%S') if self.called_at else None,
            'completed_at': self.completed_at.strftime('%Y-%m-%d %H:%M:%S') if self.completed_at else None,
            'cancelled_at': self.cancelled_at.strftime('%Y-%m-%d %H:%M:%S') if self.cancelled_at else None,
            'estimated_wait_minutes': self.estimated_wait_minutes,
            'recommended_arrival': self.recommended_arrival.strftime('%I:%M %p') if self.recommended_arrival else None,
            'recommended_arrival_full': self.recommended_arrival.strftime('%Y-%m-%d %H:%M:%S') if self.recommended_arrival else None,
            'qr_code_path': self.qr_code_path,
            'created_at': self.created_at.strftime('%Y-%m-%d %H:%M:%S') if self.created_at else None
        }
