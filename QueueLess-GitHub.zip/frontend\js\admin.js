/* ===================================================
   QueueLess Government Office - Admin Operations & Analytics
   =================================================== */

const AdminApp = {
    charts: {},

    async initDashboard() {
        try {
            const res = await API.get('/admin/analytics');
            if (res.success && res.data) {
                const data = res.data;

                // Render metrics
                document.getElementById('stat-total-citizens').textContent = data.total_citizens;
                document.getElementById('stat-active-officers').textContent = data.active_officers;
                document.getElementById('stat-active-offices').textContent = data.active_offices;
                document.getElementById('stat-today-tokens').textContent = data.today_tokens;
                document.getElementById('stat-waiting-tokens').textContent = data.waiting_tokens;
                document.getElementById('stat-completed-tokens').textContent = data.completed_tokens;
                document.getElementById('stat-avg-wait').textContent = `${data.average_wait_minutes}m`;
                document.getElementById('stat-avg-service').textContent = `${data.average_service_minutes}m`;

                // Render Charts if Chart.js loaded
                this.renderCharts(data);
            }
        } catch (err) {
            showToast('error', 'Error', 'Failed to load admin analytics');
        }
    },

    renderCharts(data) {
        if (typeof Chart === 'undefined') return;

        // 1. Status Breakdown Doughnut Chart
        const statusCtx = document.getElementById('chart-status-breakdown');
        if (statusCtx) {
            if (this.charts.status) this.charts.status.destroy();
            this.charts.status = new Chart(statusCtx, {
                type: 'doughnut',
                data: {
                    labels: ['Completed', 'Waiting', 'Cancelled', 'Skipped'],
                    datasets: [{
                        data: [
                            data.completed_tokens,
                            data.waiting_tokens,
                            data.cancelled_tokens,
                            data.skipped_tokens
                        ],
                        backgroundColor: ['#16a34a', '#f59e0b', '#dc2626', '#64748b']
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: { legend: { position: 'bottom' } }
                }
            });
        }

        // 2. Service Popularity Bar Chart
        const serviceCtx = document.getElementById('chart-service-popularity');
        if (serviceCtx && data.service_popularity) {
            if (this.charts.service) this.charts.service.destroy();
            this.charts.service = new Chart(serviceCtx, {
                type: 'bar',
                data: {
                    labels: data.service_popularity.map(s => s.service_name),
                    datasets: [{
                        label: 'Total Tokens',
                        data: data.service_popularity.map(s => s.count),
                        backgroundColor: '#2563eb',
                        borderRadius: 4
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: { legend: { display: false } },
                    scales: { y: { beginAtZero: true, ticks: { precision: 0 } } }
                }
            });
        }

        // 3. Hourly Queue Load Bar/Line Chart
        const hourlyCtx = document.getElementById('chart-hourly-load');
        if (hourlyCtx && data.hourly_distribution) {
            const hours = ['8 AM', '9 AM', '10 AM', '11 AM', '12 PM', '1 PM', '2 PM', '3 PM', '4 PM', '5 PM'];
            if (this.charts.hourly) this.charts.hourly.destroy();
            this.charts.hourly = new Chart(hourlyCtx, {
                type: 'line',
                data: {
                    labels: hours,
                    datasets: [{
                        label: 'Tokens Issued Today',
                        data: data.hourly_distribution,
                        borderColor: '#0f766e',
                        backgroundColor: 'rgba(15, 118, 110, 0.1)',
                        fill: true,
                        tension: 0.3
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    scales: { y: { beginAtZero: true, ticks: { precision: 0 } } }
                }
            });
        }
    },

    usersOffset: 0,
    usersLimit: 10,

    async loadUsers(append = false) {
        const btn = document.getElementById('btn-load-more-users');
        if (!append) {
            this.usersOffset = 0;
            const tbody = document.querySelector('#users-table tbody');
            if (tbody) tbody.innerHTML = '<tr><td colspan="7" class="text-center text-muted py-4">Loading accounts...</td></tr>';
            
            // Setup listener for the load more button if it exists and hasn't been set up
            if (btn && !btn.dataset.listenerAttached) {
                btn.addEventListener('click', () => this.loadUsers(true));
                btn.dataset.listenerAttached = 'true';
            }
        } else {
            if (btn) {
                btn.disabled = true;
                btn.innerHTML = '<span class="spinner-border spinner-border-sm me-1"></span>Loading...';
            }
        }

        try {
            const res = await API.get(`/admin/users?limit=${this.usersLimit}&offset=${this.usersOffset}`);
            const tbody = document.querySelector('#users-table tbody');
            if (tbody && res.success) {
                const html = res.data.users.map(u => `
                    <tr>
                        <td>#${u.display_number !== null && u.display_number !== undefined ? u.display_number : u.id}</td>
                        <td class="fw-semibold">${escapeHtml(u.full_name)}</td>
                        <td>${escapeHtml(u.email)}</td>
                        <td>${escapeHtml(u.mobile)}</td>
                        <td><span class="badge ${u.role === 'admin' ? 'bg-danger' : u.role === 'officer' ? 'bg-primary' : 'bg-secondary'} text-uppercase">${u.role}</span></td>
                        <td>${u.role === 'officer' ? (u.assigned_service_name ? `<span class="badge bg-info text-dark">${escapeHtml(u.assigned_service_name)}</span>` : '<span class="text-muted small">Not Assigned</span>') : '<span class="text-muted small">—</span>'}</td>
                        <td>${u.is_active ? '<span class="badge bg-success">Active</span>' : '<span class="badge bg-danger">Inactive</span>'}</td>
                        <td class="d-flex gap-1">
                            <button class="btn btn-sm btn-outline-primary" onclick='AdminApp.editUser(${JSON.stringify(u).replace(/'/g, "&apos;")})' title="Edit"><i class="bi bi-pencil"></i></button>
                            <button class="btn btn-sm btn-outline-danger" onclick="AdminApp.deleteUser(${u.id})" title="Delete">
                                <i class="bi bi-trash"></i>
                            </button>
                        </td>
                    </tr>
                `).join('');

                if (append) {
                    tbody.insertAdjacentHTML('beforeend', html);
                } else {
                    tbody.innerHTML = res.data.users.length ? html : '<tr><td colspan="7" class="text-center text-muted py-4">No accounts found.</td></tr>';
                }

                this.usersOffset += res.data.users.length;
                
                if (btn) {
                    if (this.usersOffset >= res.data.total || res.data.users.length < this.usersLimit) {
                        btn.style.display = 'none';
                    } else {
                        btn.style.display = 'inline-block';
                    }
                }
            }
        } catch (e) {
            showToast('error', 'Error', 'Failed to load users');
        } finally {
            if (append && btn) {
                btn.disabled = false;
                btn.innerHTML = 'View More';
            }
        }
    },

    editUser(user) {
        document.getElementById('edit-user-id').value = user.id;
        document.getElementById('edit-user-name').value = user.full_name;
        document.getElementById('edit-user-email').value = user.email;
        document.getElementById('edit-user-mobile').value = user.mobile;
        document.getElementById('edit-user-role').value = user.role;
        document.getElementById('edit-user-active').value = user.is_active ? "true" : "false";
        
        onEditRoleChange(); // Will show/hide service field
        
        // Wait a small tick to ensure services are loaded or visible
        setTimeout(() => {
            if (user.role === 'officer' && user.assigned_service_id) {
                document.getElementById('edit-user-service').value = user.assigned_service_id;
            } else {
                document.getElementById('edit-user-service').value = "";
            }
        }, 50);

        const modal = new bootstrap.Modal(document.getElementById('editUserModal'));
        modal.show();
    },

    async submitEditUser(e) {
        e.preventDefault();
        const id = document.getElementById('edit-user-id').value;
        const full_name = document.getElementById('edit-user-name').value.trim();
        const email = document.getElementById('edit-user-email').value.trim();
        const mobile = document.getElementById('edit-user-mobile').value.trim();
        const role = document.getElementById('edit-user-role').value;
        const is_active = document.getElementById('edit-user-active').value === "true";
        const password = document.getElementById('edit-user-password').value;
        const assigned_service_id = document.getElementById('edit-user-service').value || null;

        const payload = { full_name, email, mobile, role, is_active };
        if (password) payload.password = password;
        if (role === 'officer' && assigned_service_id) {
            payload.assigned_service_id = parseInt(assigned_service_id);
        } else {
            payload.assigned_service_id = null;
        }

        try {
            const res = await API.put(`/admin/users/${id}`, payload);
            if (res.success) {
                showToast('success', 'User Updated', 'Account updated successfully.');
                bootstrap.Modal.getInstance(document.getElementById('editUserModal')).hide();
                AdminApp.loadUsers(); // Reload to refresh table
            }
        } catch (err) {
            showToast('error', 'Update Failed', err.message);
        }
    },

    async deleteUser(userId) {
        if (!confirm('Are you sure you want to delete this user?')) return;
        try {
            const res = await API.delete(`/admin/users/${userId}`);
            if (res.success) {
                showToast('success', 'User Deleted', 'User deleted successfully.');
                this.loadUsers();
            }
        } catch (err) {
            showToast('error', 'Error', err.message || 'Failed to delete user');
        }
    },

    // ---------------- Offices Management ----------------
    async loadOffices(onEdit) {
        // Store the callback globally so the inline onclick can always find it
        if (typeof onEdit === 'function') window._officeEditCallback = onEdit;
        try {
            const res = await API.get('/offices');
            const tbody = document.querySelector('#offices-table tbody');
            if (tbody && res.success) {
                tbody.innerHTML = res.data.map(o => `
                    <tr>
                        <td class="fw-bold">${escapeHtml(o.code)}</td>
                        <td>${escapeHtml(o.name)}</td>
                        <td>${escapeHtml(o.city)}, ${escapeHtml(o.state)}</td>
                        <td>${o.opening_time} - ${o.closing_time}</td>
                        <td>${o.is_active ? '<span class="badge bg-success">Active</span>' : '<span class="badge bg-secondary">Inactive</span>'}</td>
                        <td class="d-flex gap-1">
                            <button class="btn btn-sm btn-outline-primary" onclick='window._officeEditCallback && window._officeEditCallback(${JSON.stringify(o).replace(/'/g, "&apos;")})' title="Edit"><i class="bi bi-pencil"></i></button>
                            <button class="btn btn-sm btn-outline-danger" onclick="AdminApp.deleteOffice(${o.id})" title="Delete">
                                <i class="bi bi-trash"></i>
                            </button>
                        </td>
                    </tr>
                `).join('');
            }
        } catch (e) {
            showToast('error', 'Error', 'Failed to load offices');
        }
    },

    async deleteOffice(officeId) {
        if (!confirm('Are you sure you want to delete this office and all related services/counters?')) return;
        try {
            const res = await API.delete(`/offices/${officeId}`);
            if (res.success) {
                showToast('success', 'Office Deleted', 'Office deleted successfully.');
                this.loadOffices();
            }
        } catch (err) {
            showToast('error', 'Error', err.message || 'Failed to delete office');
        }
    },

    // ---------------- Services Management ----------------
    async loadServices(onEdit) {
        // Store the callback globally so the inline onclick can always find it
        if (typeof onEdit === 'function') window._serviceEditCallback = onEdit;
        try {
            const res = await API.get('/services');
            const tbody = document.querySelector('#services-table tbody');
            if (tbody && res.success) {
                tbody.innerHTML = res.data.map(s => `
                    <tr>
                        <td class="fw-bold">${escapeHtml(s.code)}</td>
                        <td>${escapeHtml(s.name)}</td>
                        <td>${escapeHtml(s.office_name || 'N/A')}</td>
                        <td>${s.average_service_time} mins</td>
                        <td>${s.is_active ? '<span class="badge bg-success">Active</span>' : '<span class="badge bg-secondary">Inactive</span>'}</td>
                        <td class="d-flex gap-1">
                            <button class="btn btn-sm btn-outline-primary" onclick='window._serviceEditCallback && window._serviceEditCallback(${JSON.stringify(s).replace(/'/g, "&apos;")})' title="Edit"><i class="bi bi-pencil"></i></button>
                            <button class="btn btn-sm btn-outline-danger" onclick="AdminApp.deleteService(${s.id})" title="Delete">
                                <i class="bi bi-trash"></i>
                            </button>
                        </td>
                    </tr>
                `).join('');
            }
        } catch (e) {
            showToast('error', 'Error', 'Failed to load services');
        }
    },

    async deleteService(serviceId) {
        if (!confirm('Are you sure you want to delete this service?')) return;
        try {
            const res = await API.delete(`/services/${serviceId}`);
            if (res.success) {
                showToast('success', 'Service Deleted', 'Service deleted successfully.');
                this.loadServices();
            }
        } catch (err) {
            showToast('error', 'Error', err.message || 'Failed to delete service');
        }
    },

    // ---------------- Audit Logs ----------------
    auditLogsLastId: null,
    auditLogsRendered: 0,
    auditLogsLimit: 10,
    
    async loadAuditLogs(append = false) {
        const btn = document.getElementById('btn-load-more-logs');
        const footer = document.getElementById('audit-logs-footer');
        
        if (!append) {
            this.auditLogsLastId = null;
            this.auditLogsRendered = 0;
            const tbody = document.querySelector('#audit-logs-table tbody');
            if (tbody) tbody.innerHTML = '<tr><td colspan="6" class="text-center text-muted py-3">Loading logs...</td></tr>';
            if (footer) footer.classList.add('d-none');
            
            // Attach event listener once
            if (btn && !btn.dataset.listenerAttached) {
                btn.addEventListener('click', () => this.loadAuditLogs(true));
                btn.dataset.listenerAttached = 'true';
            }
        } else {
            if (btn) {
                btn.disabled = true;
                btn.innerHTML = '<span class="spinner-border spinner-border-sm me-1" role="status" aria-hidden="true"></span>Loading...';
            }
        }

        try {
            const url = `/admin/audit-logs?limit=${this.auditLogsLimit}` + (this.auditLogsLastId ? `&last_id=${this.auditLogsLastId}` : '');
            const res = await API.get(url);
            const tbody = document.querySelector('#audit-logs-table tbody');
            if (tbody && res.success) {
                const html = res.data.map((l, index) => `
                    <tr>
                        <td>#${this.auditLogsRendered + index + 1}</td>
                        <td><span class="badge bg-dark">${escapeHtml(l.action)}</span></td>
                        <td>${escapeHtml(l.entity_type)} ${l.entity_id ? '#' + l.entity_id : ''}</td>
                        <td>${escapeHtml(l.user_name)}</td>
                        <td class="small text-muted">${escapeHtml(l.details || '—')}</td>
                        <td class="small">${formatDateTime(l.created_at)}</td>
                    </tr>
                `).join('');
                
                if (append) {
                    tbody.insertAdjacentHTML('beforeend', html);
                } else {
                    tbody.innerHTML = res.data.length ? html : '<tr><td colspan="6" class="text-center text-muted py-3">No logs found.</td></tr>';
                }

                if (res.data.length > 0) {
                    this.auditLogsRendered += res.data.length;
                    this.auditLogsLastId = res.data[res.data.length - 1].id;
                }

                if (footer && res.data.length === this.auditLogsLimit) {
                    footer.classList.remove('d-none');
                } else if (footer) {
                    footer.classList.add('d-none');
                }
            }
        } catch (e) {
            showToast('error', 'Error', 'Failed to fetch audit logs. Please check your connection and retry.');
        } finally {
            if (append && btn) {
                btn.disabled = false;
                btn.innerHTML = 'View More';
            }
        }
    }
};
