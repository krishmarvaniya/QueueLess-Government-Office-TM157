/* ===================================================
   QueueLess Government Office - Auth Manager
   =================================================== */

const Auth = {
    async login(email, password) {
        try {
            const res = await API.post('/auth/login', { email, password });
            if (res.success && res.data) {
                API.setToken(res.data.token);
                API.setCurrentUser(res.data.user);
                return res.data.user;
            }
            throw new Error(res.message || 'Login failed');
        } catch (err) {
            throw err;
        }
    },

    async register(userData) {
        try {
            const res = await API.post('/auth/register', userData);
            if (res.success) {
                return res; 
            }
            throw new Error(res.message || 'Registration failed');
        } catch (err) {
            throw err;
        }
    },

    async logout() {
        try {
            await API.post('/auth/logout', {});
        } catch (e) {
            // Ignore API logout failure, clear client state regardless
        } finally {
            API.clearToken();
            window.location.href = '/login.html';
        }
    },

    async requireAuth(allowedRoles = []) {
        const token = API.getToken();
        if (!token) {
            window.location.href = `/login.html?redirect=${encodeURIComponent(window.location.pathname)}`;
            return null;
        }

        try {
            const res = await API.get('/auth/me');
            if (res.success && res.data) {
                const user = res.data;
                API.setCurrentUser(user);

                if (allowedRoles.length > 0 && !allowedRoles.includes(user.role)) {
                    // Redirect to user's appropriate portal
                    if (user.role === 'admin') window.location.href = '/admin/dashboard.html';
                    else if (user.role === 'officer') window.location.href = '/officer/dashboard.html';
                    else window.location.href = '/citizen/dashboard.html';
                    return null;
                }

                this.updateUserUI(user);
                return user;
            }
        } catch (err) {
            API.clearToken();
            window.location.href = '/login.html?expired=1';
            return null;
        }
    },

    updateUserUI(user) {
        if (!user) return;
        const nameElements = document.querySelectorAll('.auth-user-name');
        nameElements.forEach(el => el.textContent = user.full_name);

        const emailElements = document.querySelectorAll('.auth-user-email');
        emailElements.forEach(el => el.textContent = user.email);

        const roleElements = document.querySelectorAll('.auth-user-role');
        roleElements.forEach(el => el.textContent = user.role.toUpperCase());

        const avatarElements = document.querySelectorAll('.auth-user-avatar');
        avatarElements.forEach(el => {
            const initial = user.full_name ? user.full_name.charAt(0).toUpperCase() : 'U';
            el.textContent = initial;
        });

        const logoutBtns = document.querySelectorAll('.btn-logout');
        logoutBtns.forEach(btn => {
            btn.onclick = (e) => {
                e.preventDefault();
                this.logout();
            };
        });
    },

    updateUser(user) {
        if (!user) return;
        API.setCurrentUser(user);
        this.updateUserUI(user);
    }
};
