/* ===================================================
   QueueLess Government Office - Citizen Operations
   =================================================== */

const CitizenApp = {
    activeToken: null,

    async initDashboard(user) {
        if (user) {
            if(document.getElementById('dash-fullname')) document.getElementById('dash-fullname').textContent = user.full_name || '—';
            if(document.getElementById('dash-mobile')) document.getElementById('dash-mobile').textContent = user.mobile || '—';
            if(document.getElementById('dash-email')) document.getElementById('dash-email').textContent = user.email || '—';
            if(document.getElementById('dash-address')) document.getElementById('dash-address').textContent = user.address || '—';
            if(document.getElementById('dash-city')) document.getElementById('dash-city').textContent = user.city || '—';
            if(document.getElementById('dash-state')) document.getElementById('dash-state').textContent = user.state || '—';
            if(document.getElementById('dash-pincode')) document.getElementById('dash-pincode').textContent = user.pin_code || '—';
        }
        
        try {
            const res = await API.get('/tokens/my');
            if (res.success && res.data) {
                const active = res.data.active || [];
                const history = res.data.history || [];

                this.renderActiveToken(active[0] || null);
                this.renderHistory(history.slice(0, 5), 'dashboard-history-table');
            }
        } catch (err) {
            showToast('error', 'Error', 'Failed to load tokens.');
        }
    },

    renderActiveToken(token) {
        const container = document.getElementById('active-token-container');
        if (!container) return;

        if (!token) {
            container.innerHTML = `
                <div class="card p-4 text-center">
                    <div class="mb-3">
                        <i class="bi bi-ticket-perforated text-muted" style="font-size: 3rem;"></i>
                    </div>
                    <h5 class="fw-bold">No Active Token</h5>
                    <p class="text-muted">You do not have any virtual token in queue right now.</p>
                    <div class="mt-2">
                        <a href="/citizen/take-token.html" class="btn btn-primary btn-lg">
                            <i class="bi bi-plus-circle me-1"></i> Take a Virtual Token
                        </a>
                    </div>
                </div>
            `;
            return;
        }

        this.activeToken = token;

        // Join real-time room for this token
        SocketManager.init();
        SocketManager.joinTokenRoom(token.id, (updatedToken) => {
            this.renderActiveToken(updatedToken);
            showToast('info', 'Queue Updated', `Your token status is now ${updatedToken.status}`);
        });
        SocketManager.joinOfficeRoom(token.office_id);

        container.innerHTML = `
            <div class="token-hero-card fade-in">
                <div class="d-flex justify-content-between align-items-center mb-2">
                    <span class="badge bg-primary px-3 py-2 fs-6">
                        <i class="bi bi-building me-1"></i> ${escapeHtml(token.office_name)}
                    </span>
                    ${getStatusBadge(token.status)}
                </div>

                <div class="text-muted small text-uppercase fw-bold mt-2">Your Virtual Token</div>
                <div class="token-big-number">${escapeHtml(token.token_number)}</div>
                <div class="text-secondary fw-semibold mb-3">
                    <i class="bi bi-briefcase me-1"></i> ${escapeHtml(token.service_name)}
                </div>

                <div class="token-meta-grid">
                    <div class="token-meta-item">
                        <div class="meta-label">Queue Position</div>
                        <div class="meta-val text-primary">#${token.queue_position || 1}</div>
                    </div>
                    <div class="token-meta-item">
                        <div class="meta-label">People Ahead</div>
                        <div class="meta-val">${token.queue_position > 1 ? token.queue_position - 1 : 0}</div>
                    </div>
                    <div class="token-meta-item">
                        <div class="meta-label">Estimated Wait</div>
                        <div class="meta-val text-warning">${token.estimated_wait_minutes || 0} min</div>
                    </div>
                    <div class="token-meta-item">
                        <div class="meta-label">Arrival Window</div>
                        <div class="meta-val text-success">${token.recommended_arrival || 'Now'}</div>
                    </div>
                </div>

                ${token.counter_number ? `
                    <div class="alert alert-success d-flex align-items-center justify-content-center gap-2 py-2 mb-3">
                        <i class="bi bi-broadcast fs-5"></i>
                        <strong>Please proceed to Counter: ${escapeHtml(token.counter_number)}</strong>
                    </div>
                ` : ''}

                <div class="row align-items-center mt-3">
                    <div class="col-md-6 mb-3 mb-md-0">
                        ${token.qr_code_path ? `
                            <img src="${token.qr_code_path}" alt="Token QR Code" class="token-qr-img d-block">
                            <small class="text-muted d-block mt-1">Scan for verification at entrance</small>
                        ` : ''}
                    </div>
                    <div class="col-md-6 text-md-end d-flex flex-column gap-2 justify-content-center">
                        <a href="/citizen/my-token.html?id=${token.id}" class="btn btn-outline-primary">
                            <i class="bi bi-qr-code-scan me-1"></i> Full Token View & Pass
                        </a>
                        ${token.status === 'WAITING' ? `
                            <button class="btn btn-outline-danger" onclick="CitizenApp.cancelToken(${token.id})">
                                <i class="bi bi-x-circle me-1"></i> Cancel Token
                            </button>
                        ` : ''}
                    </div>
                </div>
            </div>
        `;
    },

    renderHistory(tokens, tableId = 'history-table') {
        const tableBody = document.querySelector(`#${tableId} tbody`);
        if (!tableBody) return;

        if (!tokens || tokens.length === 0) {
            tableBody.innerHTML = `<tr><td colspan="6" class="text-center text-muted py-4">No token records found.</td></tr>`;
            return;
        }

        tableBody.innerHTML = tokens.map(t => `
            <tr>
                <td class="fw-bold">${escapeHtml(t.token_number)}</td>
                <td>${escapeHtml(t.service_name)}</td>
                <td>${escapeHtml(t.office_name)}</td>
                <td>${formatDateTime(t.issued_at)}</td>
                <td>${getStatusBadge(t.status)}</td>
                <td>
                    <a href="/citizen/my-token.html?id=${t.id}" class="btn btn-sm btn-outline-primary">
                        <i class="bi bi-eye"></i> View
                    </a>
                </td>
            </tr>
        `).join('');
    },

    async cancelToken(tokenId) {
        if (!confirm('Are you sure you want to cancel your queue token?')) return;

        try {
            const res = await API.post(`/tokens/${tokenId}/cancel`, {});
            if (res.success) {
                showToast('success', 'Token Cancelled', 'Your token has been cancelled.');
                this.initDashboard();
            }
        } catch (err) {
            showToast('error', 'Error', err.message || 'Failed to cancel token');
        }
    },

    async loadTakeTokenFlow(user) {
        const officeSelect = document.getElementById('select-office');
        const serviceSelect = document.getElementById('select-service');
        const estimateBox = document.getElementById('live-estimate-box');

        if (user) {
            if(document.getElementById('tt-fullname')) document.getElementById('tt-fullname').value = user.full_name || '';
            if(document.getElementById('tt-mobile')) document.getElementById('tt-mobile').value = user.mobile || '';
            if(document.getElementById('tt-email')) document.getElementById('tt-email').value = user.email || '';
            if(document.getElementById('tt-address')) document.getElementById('tt-address').value = user.address || '';
            if(document.getElementById('tt-city')) document.getElementById('tt-city').value = user.city || '';
            if(document.getElementById('tt-state')) document.getElementById('tt-state').value = user.state || '';
            if(document.getElementById('tt-pincode')) document.getElementById('tt-pincode').value = user.pin_code || '';
        }

        if (!officeSelect || !serviceSelect) return;

        try {
            const res = await API.get('/offices');
            if (res.success && res.data) {
                officeSelect.innerHTML = '<option value="">-- Choose Government Office --</option>' +
                    res.data.map(off => `
                        <option value="${off.id}" ${!off.is_open ? 'data-closed="true"' : ''}>
                            ${escapeHtml(off.name)} (${off.city}) ${!off.is_open ? '— [CLOSED]' : ''}
                        </option>
                    `).join('');
            }
        } catch (err) {
            showToast('error', 'Error', 'Failed to load offices');
        }

        officeSelect.onchange = async () => {
            const officeId = officeSelect.value;
            serviceSelect.innerHTML = '<option value="">Loading services...</option>';
            serviceSelect.disabled = true;
            if (estimateBox) estimateBox.style.display = 'none';

            if (!officeId) {
                serviceSelect.innerHTML = '<option value="">-- Select Office First --</option>';
                return;
            }

            try {
                const res = await API.get(`/services?office_id=${officeId}`);
                if (res.success && res.data) {
                    serviceSelect.disabled = false;
                    serviceSelect.innerHTML = '<option value="">-- Choose Service --</option>' +
                        res.data.map(s => `
                            <option value="${s.id}" data-time="${s.average_service_time}">
                                ${escapeHtml(s.name)} (Avg ${s.average_service_time}m)
                            </option>
                        `).join('');
                }
            } catch (e) {
                showToast('error', 'Error', 'Failed to load services');
            }
        };

        serviceSelect.onchange = async () => {
            const officeId = officeSelect.value;
            const serviceId = serviceSelect.value;
            if (!officeId || !serviceId || !estimateBox) return;

            try {
                const res = await API.post('/prediction/estimate', {
                    office_id: parseInt(officeId),
                    service_id: parseInt(serviceId)
                });
                if (res.success && res.data) {
                    estimateBox.style.display = 'block';
                    document.getElementById('est-people-waiting').textContent = res.data.people_waiting;
                    document.getElementById('est-wait-minutes').textContent = `${res.data.estimated_wait_minutes} mins`;
                    document.getElementById('est-method').textContent = res.data.method;
                }
            } catch (e) {
                console.error(e);
            }
        };
    },

    async submitTakeToken(formEl) {
        const submitBtn = formEl.querySelector('button[type="submit"]');
        const officeId = formEl.querySelector('#select-office').value;
        const serviceId = formEl.querySelector('#select-service').value;

        if (!officeId || !serviceId) {
            showToast('warning', 'Selection Required', 'Please select both an office and a service.');
            return;
        }

        setButtonLoading(submitBtn, true, 'Generating Token...');

        try {
            const payload = {
                office_id: parseInt(officeId),
                service_id: parseInt(serviceId)
            };
            
            if(document.getElementById('tt-fullname')) payload.full_name = document.getElementById('tt-fullname').value;
            if(document.getElementById('tt-mobile')) payload.mobile = document.getElementById('tt-mobile').value;
            if(document.getElementById('tt-email')) payload.email = document.getElementById('tt-email').value;
            if(document.getElementById('tt-address')) payload.address = document.getElementById('tt-address').value;
            if(document.getElementById('tt-city')) payload.city = document.getElementById('tt-city').value;
            if(document.getElementById('tt-state')) payload.state = document.getElementById('tt-state').value;
            if(document.getElementById('tt-pincode')) payload.pin_code = document.getElementById('tt-pincode').value;

            const res = await API.post('/tokens', payload);

            if (res.success && res.data) {
                showToast('success', 'Token Generated!', `Token: ${res.data.token_number}`);
                setTimeout(() => {
                    window.location.href = `/citizen/my-token.html?id=${res.data.id}`;
                }, 800);
            }
        } catch (err) {
            showToast('error', 'Token Generation Failed', err.message || 'Unable to generate token');
        } finally {
            setButtonLoading(submitBtn, false);
        }
    }
};
