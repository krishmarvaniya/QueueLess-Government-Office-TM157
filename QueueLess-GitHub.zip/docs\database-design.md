# QueueLess Government Office — Database Design

## 1. Entity-Relationship Model

```mermaid
erDiagram
    USERS ||--o{ TOKENS : "owns"
    USERS ||--o{ NOTIFICATIONS : "receives"
    USERS ||--o{ AUDIT_LOGS : "triggers"
    USERS ||--o{ COUNTERS : "assigned_to"

    OFFICES ||--o{ SERVICES : "offers"
    OFFICES ||--o{ COUNTERS : "operates"
    OFFICES ||--o{ TOKENS : "processes"

    SERVICES ||--o{ TOKENS : "categorizes"
    COUNTERS ||--o{ TOKENS : "serves"

    TOKENS ||--o{ NOTIFICATIONS : "triggers"
    TOKENS ||--o{ PREDICTION_HISTORY : "records"

    USERS {
        int id PK
        string full_name
        string email UK
        string mobile
        string password_hash
        enum role "citizen, officer, admin"
        boolean is_active
        datetime created_at
        datetime updated_at
    }

    OFFICES {
        int id PK
        string name
        string code UK
        string address
        string city
        string state
        time opening_time
        time closing_time
        boolean is_active
        datetime created_at
    }

    SERVICES {
        int id PK
        int office_id FK
        string name
        string code
        text description
        int average_service_time
        boolean is_active
        datetime created_at
    }

    COUNTERS {
        int id PK
        int office_id FK
        string counter_number
        int assigned_officer_id FK
        boolean is_active
    }

    TOKENS {
        int id PK
        string token_number
        int user_id FK
        int office_id FK
        int service_id FK
        int counter_id FK
        enum status "WAITING, SERVING, COMPLETED, SKIPPED, CANCELLED"
        int queue_position
        datetime issued_at
        datetime called_at
        datetime completed_at
        datetime cancelled_at
        int estimated_wait_minutes
        datetime recommended_arrival
        string qr_code_path
        datetime created_at
    }

    NOTIFICATIONS {
        int id PK
        int user_id FK
        int token_id FK
        string title
        text message
        string type
        boolean is_read
        datetime created_at
    }

    PREDICTION_HISTORY {
        int id PK
        int token_id FK
        int queue_length
        int people_ahead
        int active_counters
        int average_service_time
        int hour
        int day_of_week
        float predicted_wait
        float actual_wait
        datetime created_at
    }

    AUDIT_LOGS {
        int id PK
        int user_id FK
        string action
        string entity_type
        int entity_id
        text details
        datetime created_at
    }
```

## 2. Table Summaries & Optimization

- **Indexing**: High frequency query indexes on `users(email)`, `users(role)`, `offices(code)`, `tokens(token_number)`, `tokens(status)`, and `tokens(office_id, service_id)`.
- **Integrity**: Cascading deletions where appropriate, foreign key protection, and unique constraints ensuring no two counters share the same number in the same office (`uk_office_counter`).
