from flask import Blueprint, request, g
from backend.extensions import db
from backend.models.office import Office
from backend.models.audit_log import AuditLog
from backend.utils.decorators import success_response, error_response, roles_required, login_required
from backend.utils.validators import validate_required_fields, parse_time_str

offices_bp = Blueprint('offices', __name__, url_prefix='/api/offices')

@offices_bp.route('', methods=['GET'])
def list_offices():
    offices = Office.query.all()
    results = []
    for off in offices:
        item = off.to_dict()
        item['is_open'] = off.is_open_now()
        results.append(item)
    return success_response(results, "Offices list retrieved", 200)

@offices_bp.route('/<int:office_id>', methods=['GET'])
def get_office(office_id):
    office = Office.query.get(office_id)
    if not office:
        return error_response("Office not found", "NOT_FOUND", 404)
    res = office.to_dict()
    res['is_open'] = office.is_open_now()
    res['services'] = [s.to_dict() for s in office.services.filter_by(is_active=True).all()]
    return success_response(res, "Office details retrieved", 200)

@offices_bp.route('', methods=['POST'])
@roles_required('admin')
def create_office():
    data = request.get_json() or {}
    missing = validate_required_fields(data, ['name', 'code', 'address', 'city', 'state'])
    if missing:
        return error_response(f"Missing required fields: {', '.join(missing)}", "VALIDATION_ERROR", 400)

    code = data['code'].strip().upper()
    if Office.query.filter_by(code=code).first():
        return error_response(f"Office code '{code}' already exists", "DUPLICATE_CODE", 409)

    open_time = parse_time_str(data.get('opening_time', '09:00:00'))
    close_time = parse_time_str(data.get('closing_time', '17:00:00'))

    office = Office(
        name=data['name'].strip(),
        code=code,
        address=data['address'].strip(),
        city=data['city'].strip(),
        state=data['state'].strip(),
        opening_time=open_time or '09:00:00',
        closing_time=close_time or '17:00:00',
        is_active=bool(data.get('is_active', True))
    )
    db.session.add(office)
    db.session.commit()

    audit = AuditLog(user_id=g.current_user.id, action='OFFICE_CREATED', entity_type='OFFICE', entity_id=office.id, details=f"Created office {office.name} ({office.code})")
    db.session.add(audit)
    db.session.commit()

    return success_response(office.to_dict(), "Office created successfully", 201)

@offices_bp.route('/<int:office_id>', methods=['PUT'])
@roles_required('admin')
def update_office(office_id):
    office = Office.query.get(office_id)
    if not office:
        return error_response("Office not found", "NOT_FOUND", 404)

    data = request.get_json() or {}
    if 'name' in data:
        office.name = data['name'].strip()
    if 'address' in data:
        office.address = data['address'].strip()
    if 'city' in data:
        office.city = data['city'].strip()
    if 'state' in data:
        office.state = data['state'].strip()
    if 'is_active' in data:
        office.is_active = bool(data['is_active'])
    if 'opening_time' in data:
        t = parse_time_str(data['opening_time'])
        if t: office.opening_time = t
    if 'closing_time' in data:
        t = parse_time_str(data['closing_time'])
        if t: office.closing_time = t

    db.session.commit()
    return success_response(office.to_dict(), "Office updated successfully", 200)

@offices_bp.route('/<int:office_id>', methods=['DELETE'])
@roles_required('admin')
def delete_office(office_id):
    office = Office.query.get(office_id)
    if not office:
        return error_response("Office not found", "NOT_FOUND", 404)

    db.session.delete(office)
    db.session.commit()
    return success_response(None, "Office deleted successfully", 200)
