# QueueLess Government Office — Deployment Reference

Please refer to [`docs/deployment.md`](file:///d:/QueueLess%20Government%20Office/docs/deployment.md) for complete architecture and hosting instructions.

### Quick Start with Docker
```bash
docker-compose up -d --build
```
Web application will be accessible at: `http://localhost:5000`

### Quick Start with Local Python & MySQL
```bash
# 1. Start MySQL daemon on localhost:3306
# 2. Import database schema & seed
# 3. Train ML Model
python ml/train_model.py
# 4. Start Flask server
python backend/app.py
```
