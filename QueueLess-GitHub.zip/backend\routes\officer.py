from flask import Blueprint, request, g
from backend.extensions import db
from backend.models.counter import Counter
from backend.models.token import Token
from backend.services.queue_service import (
    call_next_token,
    complete_current_token,
    skip_current_token,
    recall_current_token
)
from backend.utils.decorators import success_response, error_response, roles_required

officer_bp = Blueprint('officer', __name__, url_prefix='/api/officer')

@officer_bp.route('/dashboard-data', methods=['GET'])
@roles_required('officer', 'admin')
def get_dashboard_data():
    user = g.current_user
    counter = Counter.query.filter_by(assigned_officer_id=user.id, is_active=True).first()
    
    if not counter:
        counter_id = request.args.get('counter_id', type=int)
        if counter_id:
            counter = Counter.query.get(counter_id)
            
    if not counter:
        return error_response("No counter assigned", "NO_COUNTER", 400)
        
    office_id = counter.office_id
    if user.role == 'officer' and not user.assigned_service_id:
        return error_response("No service assigned to your account. Please contact Admin.", "NO_SERVICE", 403)

    svc_filter = user.assigned_service_id if user.role == 'officer' else None

    # 1. Get all active counters for this office
    all_counters = Counter.query.filter_by(office_id=office_id, is_active=True).all()
    counters_data = []
    
    # Get all unassigned WAITING tokens
    unassigned_query = Token.query.filter_by(office_id=office_id, status='WAITING').filter(Token.counter_id.is_(None))
    if svc_filter:
        unassigned_query = unassigned_query.filter_by(service_id=svc_filter)
    unassigned_waiting = unassigned_query.order_by(Token.issued_at.asc()).all()
    
    for c in all_counters:
        c_data = c.to_dict()
        
        # Current serving token
        serving_query = Token.query.filter_by(counter_id=c.id, status='SERVING')
        if svc_filter:
            serving_query = serving_query.filter_by(service_id=svc_filter)
        serving = serving_query.first()

        c_data['current_token'] = serving.to_dict() if serving else None
        c_data['status'] = 'SERVING' if serving else 'IDLE'
        
        # Waiting specifically for this counter
        assigned_query = Token.query.filter_by(office_id=office_id, counter_id=c.id, status='WAITING')
        if svc_filter:
            assigned_query = assigned_query.filter_by(service_id=svc_filter)
        assigned_waiting = assigned_query.order_by(Token.issued_at.asc()).all()

        c_data['citizens_waiting'] = len(assigned_waiting)
        
        # Next token
        if assigned_waiting:
            c_data['next_token'] = assigned_waiting[0].to_dict()
            c_data['estimated_wait'] = assigned_waiting[0].estimated_wait_minutes
        elif unassigned_waiting:
            c_data['next_token'] = unassigned_waiting[0].to_dict()
            c_data['estimated_wait'] = unassigned_waiting[0].estimated_wait_minutes
        else:
            c_data['next_token'] = None
            c_data['estimated_wait'] = 0
            
        counters_data.append(c_data)
        
    from sqlalchemy import case as sa_case
    # 2. Get all waiting and serving tokens for this office
    queue_query = Token.query.filter(
        Token.office_id == office_id, 
        Token.status.in_(['WAITING', 'SERVING'])
    )
    if svc_filter:
        queue_query = queue_query.filter_by(service_id=svc_filter)
        
    all_queue_tokens = queue_query.order_by(
        sa_case((Token.status == 'SERVING', 0), else_=1),
        Token.queue_position.asc(), 
        Token.issued_at.asc()
    ).all()
    queue_data = [t.to_dict() for t in all_queue_tokens]
    
    return success_response({
        'all_counters': counters_data,
        'waiting_tokens': queue_data
    }, "Dashboard data retrieved", 200)

@officer_bp.route('/status', methods=['GET'])
@roles_required('officer', 'admin')
def get_officer_status():
    user = g.current_user
    counter = Counter.query.filter_by(assigned_officer_id=user.id, is_active=True).first()

    # If not assigned, allow selecting any active counter in their office
    if not counter:
        # Check if counter_id provided in query
        counter_id = request.args.get('counter_id', type=int)
        if counter_id:
            counter = Counter.query.get(counter_id)

    if not counter:
        available_counters = Counter.query.filter_by(is_active=True).all()
        return success_response({
            'counter': None,
            'available_counters': [c.to_dict() for c in available_counters],
            'current_token': None,
            'next_token': None,
            'waiting_count': 0
        }, "No counter currently assigned to officer", 200)
    if user.role == 'officer' and not user.assigned_service_id:
        return error_response("No service assigned to your account. Please contact Admin.", "NO_SERVICE", 403)

    svc_filter = user.assigned_service_id if user.role == 'officer' else None

    # Current serving token at this counter
    serving_query = Token.query.filter_by(counter_id=counter.id, status='SERVING')
    if svc_filter:
        serving_query = serving_query.filter_by(service_id=svc_filter)
    current_token = serving_query.first()

    # Next token in line for this office and service
    next_query = Token.query.filter_by(office_id=counter.office_id, status='WAITING')
    if svc_filter:
        next_query = next_query.filter_by(service_id=svc_filter)
    next_token = next_query.order_by(Token.issued_at.asc()).first()

    waiting_count = next_query.count()

    from datetime import datetime, date
    today_start = datetime.combine(date.today(), datetime.min.time())
    
    # Calculate average service time of today's completed tokens for THIS officer
    completed_today = Token.query.filter(
        Token.officer_id == user.id,
        Token.status == 'COMPLETED',
        Token.completed_at >= today_start
    ).all()

    avg_service_mins = 0
    if completed_today:
        durations = []
        for t in completed_today:
            if t.called_at and t.completed_at:
                durations.append((t.completed_at - t.called_at).total_seconds() / 60.0)
        if durations:
            avg_service_mins = round(sum(durations) / len(durations), 1)

    return success_response({
        'counter': counter.to_dict(),
        'current_token': current_token.to_dict() if current_token else None,
        'next_token': next_token.to_dict() if next_token else None,
        'waiting_count': waiting_count,
        'average_service_time': avg_service_mins or 4.5,
        'completed_today_count': len(completed_today)
    }, "Officer dashboard status retrieved", 200)

@officer_bp.route('/counter/assign', methods=['POST'])
@roles_required('officer', 'admin')
def assign_counter():
    data = request.get_json() or {}
    counter_id = data.get('counter_id')
    if not counter_id:
        return error_response("counter_id is required", "VALIDATION_ERROR", 400)

    counter = Counter.query.get(counter_id)
    if not counter:
        return error_response("Counter not found", "NOT_FOUND", 404)

    # Clear previous counter assignment
    old_counter = Counter.query.filter_by(assigned_officer_id=g.current_user.id).first()
    if old_counter and old_counter.id != counter.id:
        old_counter.assigned_officer_id = None

    counter.assigned_officer_id = g.current_user.id
    db.session.commit()

    return success_response(counter.to_dict(), "Counter assigned successfully", 200)

@officer_bp.route('/next', methods=['POST'])
@roles_required('officer', 'admin')
def call_next():
    data = request.get_json() or {}
    counter_id = data.get('counter_id')
    
    if not counter_id:
        counter = Counter.query.filter_by(assigned_officer_id=g.current_user.id).first()
        if counter:
            counter_id = counter.id

    if not counter_id:
        return error_response("Officer must have an assigned counter or provide counter_id", "COUNTER_REQUIRED", 400)

    if g.current_user.role == 'officer':
        if not g.current_user.assigned_service_id:
            return error_response("No service assigned to your account. Please contact Admin.", "NO_SERVICE", 403)
        service_id = g.current_user.assigned_service_id
    else:
        service_id = data.get('service_id')

    token, err = call_next_token(g.current_user.id, counter_id, service_id)
    if err:
        return error_response(err, "CALL_NEXT_FAILED", 400)

    return success_response(token.to_dict(), f"Called token {token.token_number}", 200)

@officer_bp.route('/token/<int:token_id>/complete', methods=['POST'])
@roles_required('officer', 'admin')
def complete_token(token_id):
    token, err = complete_current_token(token_id, g.current_user.id)
    if err:
        return error_response(err, "COMPLETE_FAILED", 400)

    return success_response(token.to_dict(), f"Token {token.token_number} marked completed", 200)

@officer_bp.route('/token/<int:token_id>/skip', methods=['POST'])
@roles_required('officer', 'admin')
def skip_token(token_id):
    token, err = skip_current_token(token_id, g.current_user.id)
    if err:
        return error_response(err, "SKIP_FAILED", 400)

    return success_response(token.to_dict(), f"Token {token.token_number} marked skipped", 200)

@officer_bp.route('/token/<int:token_id>/recall', methods=['POST'])
@roles_required('officer', 'admin')
def recall_token(token_id):
    token, err = recall_current_token(token_id, g.current_user.id)
    if err:
        return error_response(err, "RECALL_FAILED", 400)

    return success_response(token.to_dict(), f"Token {token.token_number} re-called", 200)

@officer_bp.route('/history', methods=['GET'])
@roles_required('officer', 'admin')
def token_history():
    user = g.current_user
    
    # Pagination
    limit = request.args.get('limit', default=10, type=int)
    offset = request.args.get('offset', default=0, type=int)
    
    # Filters
    search = request.args.get('search', type=str)
    date_filter = request.args.get('date', type=str)
    status_filter = request.args.get('status', type=str)
    service_id = request.args.get('service_id', type=int)
    counter_id = request.args.get('counter_id', type=int)
    
    query = Token.query.filter(Token.officer_id == user.id)
    
    if search:
        query = query.filter(Token.token_number.ilike(f"%{search}%"))
    
    if status_filter:
        query = query.filter(Token.status == status_filter)
    else:
        # Include completed, skipped, cancelled by default
        query = query.filter(Token.status.in_(['COMPLETED', 'SKIPPED', 'CANCELLED']))
        
    if service_id:
        query = query.filter(Token.service_id == service_id)
        
    if counter_id:
        query = query.filter(Token.counter_id == counter_id)
        
    if date_filter:
        from datetime import datetime
        try:
            date_obj = datetime.strptime(date_filter, '%Y-%m-%d').date()
            query = query.filter(db.cast(Token.created_at, db.Date) == date_obj)
        except ValueError:
            pass # Ignore invalid date format
            
    # Sort newest first (using created_at or called_at/completed_at)
    query = query.order_by(Token.created_at.desc())
    
    tokens = query.offset(offset).limit(limit).all()
    
    return success_response({
        'history': [t.to_dict() for t in tokens],
        'has_more': len(tokens) == limit
    }, "Token history retrieved", 200)
